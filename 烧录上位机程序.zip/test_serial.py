import serial
import time
import threading

def send_test_data():
    ser = serial.Serial('COM2', 115200, timeout=1)
    print("已连接到 COM2")
    
    # 发送测试数据
    for ch in range(1, 13):
        time.sleep(0.2)
        ser.write(f"[{ch:02d}]STATUS:ERASING\r\n".encode())
        print(f"发送: [{ch:02d}]STATUS:ERASING")
        
        for p in range(0, 51, 10):
            time.sleep(0.1)
            ser.write(f"[{ch:02d}]PROGRESS:{p}\r\n".encode())
        
        ser.write(f"[{ch:02d}]STATUS:PROGRAMMING\r\n".encode())
        print(f"发送: [{ch:02d}]STATUS:PROGRAMMING")
        
        for p in range(50, 101, 10):
            time.sleep(0.1)
            ser.write(f"[{ch:02d}]PROGRESS:{p}\r\n".encode())
        
        ser.write(f"[{ch:02d}]RESULT:SUCCESS\r\n".encode())
        print(f"发送: [{ch:02d}]RESULT:SUCCESS")
        
        # 发送简单的二维码（模拟数据）
        qr_data = "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAOUlEQVRIS2NkGGDAOMJZMAowGFjY2BgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBAYGBiYGBgYGBgYGBiYP+ACmFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWBhYWFhYWFhYWBhYWB/gAhhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWBhYWFhYWFhYWBhYWB8AAAAASUVORK5CYII="
        ser.write(f"[{ch:02d}]QRCODE:{qr_data}\r\n".encode())
        print(f"发送: [{ch:02d}]QRCODE:...")
    
    ser.close()
    print("测试完成！")

if __name__ == "__main__":
    send_test_data()
