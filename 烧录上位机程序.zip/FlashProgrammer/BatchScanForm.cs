using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Media;

namespace FlashProgrammer;

public partial class BatchScanForm : Form
{
    private readonly Func<string, string?>? _codeValidator;
    private readonly int _totalChannels;
    private int _currentChannel = 1;
    private readonly Dictionary<int, string> _scannedData = new Dictionary<int, string>();
    private DateTime _lastScanTime = DateTime.MinValue;

    public Dictionary<int, string> ScannedData => _scannedData;
    public bool IsCompleted => _scannedData.Count == _totalChannels;

    private TextBox txtManualInput = null!;
    private Label lblStatus = null!;
    private Label lblHint = null!;
    private ListView lvProgress = null!;
    private Button btnConfirm = null!;
    private Button btnCancel = null!;
    private Button btnSkip = null!;
    private System.Windows.Forms.Timer _autoSubmitTimer = null!;
    private bool _isSubmitting;
    private bool _isWaitingForStart;

    public BatchScanForm(int totalChannels, Func<string, string?>? codeValidator = null)
    {
        _totalChannels = totalChannels;
        _codeValidator = codeValidator;
        InitializeComponent();
        FormDisplayHelper.FitToWorkingArea(this, new Size(560, 680), new Size(520, 620));
    }

    private void InitializeComponent()
    {
        this.Text = "批量扫码确认";
        this.Size = new Size(560, 680);
        this.StartPosition = FormStartPosition.CenterParent;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.KeyPreview = true;

        lblHint = new Label
        {
            Text = "请扫描或输入二维码内容，内容输入后 0.5 秒将自动录入并跳转。",
            Location = new Point(20, 15),
            Size = new Size(500, 42),
            Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold)
        };

        _autoSubmitTimer = new System.Windows.Forms.Timer { Interval = 500 };
        _autoSubmitTimer.Tick += (s, e) => {
            _autoSubmitTimer.Stop();
            string code = txtManualInput.Text.Trim();
            if (!string.IsNullOrWhiteSpace(code)) {
                ProcessScannedCode(code);
            }
        };

        txtManualInput = new TextBox
        {
            Location = new Point(20, 62),
            Size = new Size(360, 38),
            Font = new Font("Microsoft YaHei UI", 12F),
            BorderStyle = BorderStyle.FixedSingle,
            TabStop = true
        };

        btnConfirm = new Button
        {
            Text = "确定",
            Location = new Point(390, 60),
            Size = new Size(140, 42),
            BackColor = Color.FromArgb(46, 204, 113),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold)
        };
        btnConfirm.FlatAppearance.BorderSize = 0;
        btnConfirm.Click += BtnConfirm_Click;

        lblStatus = new Label
        {
            Location = new Point(20, 115),
            Size = new Size(510, 138),
            Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Bold),
            ForeColor = Color.Blue,
            TextAlign = ContentAlignment.MiddleLeft,
            BorderStyle = BorderStyle.FixedSingle,
            Padding = new Padding(12, 8, 12, 8),
            Text = $"请扫描 通道 {_currentChannel} 的二维码 ({_currentChannel}/{_totalChannels})"
        };

        lvProgress = new ListView
        {
            Location = new Point(20, 263),
            Size = new Size(510, 272),
            View = View.Details,
            FullRowSelect = true,
            GridLines = true,
            Font = new Font("Microsoft YaHei UI", 9F),
            TabStop = false
        };
        lvProgress.Columns.Add("通道", 60);
        lvProgress.Columns.Add("状态/条码", 420);
        
        for (int i = 1; i <= _totalChannels; i++)
        {
            var item = new ListViewItem($"CH {i:D2}");
            item.SubItems.Add(i == 1 ? "等待扫码..." : "未开始");
            if (i == 1) item.BackColor = Color.LightCyan;
            lvProgress.Items.Add(item);
        }

        btnSkip = new Button
        {
            Text = "跳过此通道",
            Location = new Point(20, 560),
            Size = new Size(140, 40),
            BackColor = Color.Orange,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            TabStop = false
        };
        btnSkip.FlatAppearance.BorderSize = 0;
        btnSkip.Click += BtnSkip_Click;

        btnCancel = new Button
        {
            Text = "取消批量扫码",
            Location = new Point(380, 560),
            Size = new Size(140, 40),
            BackColor = Color.Gray,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            TabStop = false
        };
        btnCancel.FlatAppearance.BorderSize = 0;
        btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

        this.Controls.Add(lblHint);
        this.Controls.Add(txtManualInput);
        this.Controls.Add(btnConfirm);
        this.Controls.Add(lblStatus);
        this.Controls.Add(lvProgress);
        this.Controls.Add(btnSkip);
        this.Controls.Add(btnCancel);

        this.Load += BatchScanForm_Load;
        this.Shown += BatchScanForm_Shown;
        this.Activated += BatchScanForm_Activated;
        txtManualInput.KeyDown += TxtManualInput_KeyDown;
        txtManualInput.TextChanged += (s, e) => {
            if (_isSubmitting || _isWaitingForStart)
            {
                return;
            }
            _autoSubmitTimer.Stop();
            if (!string.IsNullOrWhiteSpace(txtManualInput.Text)) {
                lblStatus.Text = $"已识别内容，0.5 秒后自动录入通道 {_currentChannel}";
                lblStatus.ForeColor = Color.DarkOrange;
                _autoSubmitTimer.Start();
            }
            else if (_currentChannel <= _totalChannels)
            {
                lblStatus.Text = $"请扫描 通道 {_currentChannel} 的二维码 ({_currentChannel}/{_totalChannels})";
                lblStatus.ForeColor = Color.Blue;
            }
        };
    }

    private void BatchScanForm_Load(object? sender, EventArgs e)
    {
        PrepareForScanning();
    }

    private void BatchScanForm_Shown(object? sender, EventArgs e)
    {
        PrepareForScanning();
    }

    private void BatchScanForm_Activated(object? sender, EventArgs e)
    {
        PrepareForScanning();
    }

    private void PrepareForScanning()
    {
        _autoSubmitTimer.Stop();
        _isSubmitting = false;
        if (!string.IsNullOrWhiteSpace(txtManualInput.Text))
        {
            return;
        }
        txtManualInput.Focus();
        txtManualInput.SelectAll();
    }

    private void TxtManualInput_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode != Keys.Enter)
        {
            return;
        }

        e.SuppressKeyPress = true;
        SubmitCurrentInput();
    }

    private void BtnConfirm_Click(object? sender, EventArgs e)
    {
        if (_isWaitingForStart)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
            return;
        }

        SubmitCurrentInput();
    }

    private void ProcessScannedCode(string code)
    {
        if (this.InvokeRequired)
        {
            this.BeginInvoke(new Action(() => ProcessScannedCode(code)));
            return;
        }

        code = code.Trim();
        if (string.IsNullOrWhiteSpace(code))
            return;

        // 防抖：500ms内不重复处理（防止扫码枪多发回车）
        if ((DateTime.Now - _lastScanTime).TotalMilliseconds < 500)
            return;

        int duplicateChannel = _scannedData
            .Where(x => string.Equals(x.Value, code, StringComparison.OrdinalIgnoreCase))
            .Select(x => x.Key)
            .FirstOrDefault();

        if (duplicateChannel > 0)
        {
            lblStatus.Text = $"二维码重复：该码已录入通道 {duplicateChannel}，请更换下一块板子";
            lblStatus.ForeColor = Color.Red;
            SystemSounds.Hand.Play();
            PrepareForScanning();
            return;
        }

        string? validationError = _codeValidator?.Invoke(code);
        if (!string.IsNullOrWhiteSpace(validationError))
        {
            lblStatus.Text = validationError;
            lblStatus.ForeColor = Color.Red;
            SystemSounds.Hand.Play();
            PrepareForScanning();
            return;
        }

        _lastScanTime = DateTime.Now;
        _isSubmitting = true;

        // 记录数据
        _scannedData[_currentChannel] = code;
        lblStatus.ForeColor = Color.Blue;
        txtManualInput.Clear();

        // 播放成功提示音
        SystemSounds.Beep.Play();

        // 更新列表 UI
        UpdateListView(_currentChannel, code, Color.LightGreen);

        // 推进到下一个通道
        AdvanceToNextChannel();
    }

    private void BtnSkip_Click(object? sender, EventArgs e)
    {
        if (_currentChannel < 1 || _currentChannel > _totalChannels)
        {
            return;
        }

        UpdateListView(_currentChannel, "[已跳过]", Color.LightGray);
        AdvanceToNextChannel();
        PrepareForScanning();
    }

    private void UpdateListView(int channel, string text, Color backColor)
    {
        if (channel < 1 || channel > lvProgress.Items.Count)
        {
            return;
        }

        var item = lvProgress.Items[channel - 1];
        item.SubItems[1].Text = text;
        item.BackColor = backColor;
        item.EnsureVisible();
    }

    private void AdvanceToNextChannel()
    {
        _currentChannel++;

        if (_currentChannel > _totalChannels)
        {
            _isWaitingForStart = true;
            _isSubmitting = false;
            lblHint.Text = "二维码已全部录入，请将产品放入治具并压下后，再点击“开始烧录”。";
            lblStatus.Text = "★ 所有通道扫码完成 ★\n请确认产品已放好并压下治具，然后点击下方“开始烧录”按钮。";
            lblStatus.ForeColor = Color.Red;
            lblStatus.BackColor = Color.LightYellow;
            txtManualInput.Enabled = false;
            btnSkip.Enabled = false;
            btnConfirm.Enabled = true;
            btnConfirm.Text = "开始烧录";
            btnConfirm.SetBounds(382, 58, 148, 46);
            btnConfirm.Font = new Font("Microsoft YaHei UI", 11F, FontStyle.Bold);
            btnConfirm.BackColor = Color.FromArgb(52, 152, 219);
            btnCancel.Text = "返回检查";
            
            // 强行把焦点给到开始烧录按钮
            btnConfirm.Focus();
            return;
        }
        else
        {
            lblStatus.Text = $"请扫描 通道 {_currentChannel} 的二维码 ({_currentChannel}/{_totalChannels})";
            lblStatus.ForeColor = Color.Blue;
            txtManualInput.Enabled = true;
            btnConfirm.Enabled = true;
            btnSkip.Enabled = true;
            
            // 高亮下一个通道
            var nextItem = lvProgress.Items[_currentChannel - 1];
            nextItem.SubItems[1].Text = "等待扫码...";
            nextItem.BackColor = Color.LightCyan;
            nextItem.EnsureVisible();
        }

        PrepareForScanning();
    }

    private void SubmitCurrentInput()
    {
        _autoSubmitTimer.Stop();
        if (_isSubmitting)
        {
            return;
        }

        string code = txtManualInput.Text.Trim();
        if (string.IsNullOrWhiteSpace(code))
        {
            PrepareForScanning();
            return;
        }

        ProcessScannedCode(code);
    }
}
