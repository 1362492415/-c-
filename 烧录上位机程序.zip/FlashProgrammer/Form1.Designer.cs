namespace FlashProgrammer;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;
    private GroupBox groupSerial;
    private Label lblPort;
    private ComboBox cboPort;
    private Label lblBaudRate;
    private ComboBox cboBaudRate;
    private Button btnConnect;
    private Label lblChannelCount;
    private ComboBox cboChannelCount;
    private Button btnApplyConfig;
    private Button btnSaveConfig;
    private GroupBox groupChannels;
    private FlowLayoutPanel flowPanelChannels;
    private GroupBox groupControls;
    private Button btnStartAll;
        private Button btnBatchScanStart;
        private Button btnStopAll;
    private Button btnResetAll;
    private Button btnTraceQuery;
    private Button btnReadDeviceInfo;
    private RichTextBox txtLog;
    private Button btnLoopTest;
    private Label lblLoopTestStatus;
    private GroupBox groupLog;
    private Panel splitterPanel;
    private bool isDragging = false;
    private ChannelControl[] channelControls = null!;
    private AppConfig config = null!;
    private const int MinChannelAreaHeight = 220;
    private const int MinLogAreaHeight = 180;
    private int lastLogAreaHeight = 510;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.groupSerial = new GroupBox();
        this.lblPort = new Label();
        this.cboPort = new ComboBox();
        this.lblBaudRate = new Label();
        this.cboBaudRate = new ComboBox();
        this.btnConnect = new Button();
        this.lblChannelCount = new Label();
        this.cboChannelCount = new ComboBox();
        this.btnApplyConfig = new Button();
        this.btnSaveConfig = new Button();
        this.btnReadDeviceInfo = new Button();
        this.btnLoopTest = new Button();
        this.lblLoopTestStatus = new Label();
        this.groupChannels = new GroupBox();
        this.flowPanelChannels = new FlowLayoutPanel();
        this.groupControls = new GroupBox();
        this.btnStartAll = new Button();
        this.btnBatchScanStart = new Button();
        this.btnStopAll = new Button();
        this.btnResetAll = new Button();
        this.btnTraceQuery = new Button();
        this.txtLog = new RichTextBox();
        this.groupLog = new GroupBox();
        this.splitterPanel = new Panel();

        this.groupSerial.SuspendLayout();
        this.groupChannels.SuspendLayout();
        this.groupControls.SuspendLayout();
        this.groupLog.SuspendLayout();
        this.splitterPanel.SuspendLayout();
        this.SuspendLayout();

        this.groupSerial.Controls.Add(this.btnConnect);
        this.groupSerial.Controls.Add(this.cboBaudRate);
        this.groupSerial.Controls.Add(this.lblBaudRate);
        this.groupSerial.Controls.Add(this.cboPort);
        this.groupSerial.Controls.Add(this.lblPort);
        this.groupSerial.Controls.Add(this.lblChannelCount);
        this.groupSerial.Controls.Add(this.cboChannelCount);
        this.groupSerial.Controls.Add(this.btnApplyConfig);
        this.groupSerial.Controls.Add(this.btnSaveConfig);
        this.groupSerial.Controls.Add(this.btnReadDeviceInfo);
        this.groupSerial.Controls.Add(this.btnLoopTest);
        this.groupSerial.Controls.Add(this.lblLoopTestStatus);
        this.groupSerial.Location = new Point(11, 11);
        this.groupSerial.Size = new Size(2300, 70);
        this.groupSerial.TabIndex = 0;
        this.groupSerial.TabStop = false;
        this.groupSerial.Text = "串口设置";
        this.groupSerial.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Bold, GraphicsUnit.Point);
        this.groupSerial.ForeColor = Color.FromArgb(60, 60, 60);

        this.lblPort.AutoSize = true;
        this.lblPort.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblPort.Location = new Point(14, 28);
        this.lblPort.Size = new Size(32, 17);
        this.lblPort.TabIndex = 0;
        this.lblPort.Text = "端口:";
        this.lblPort.ForeColor = Color.FromArgb(80, 80, 80);

        this.cboPort.Location = new Point(49, 25);
        this.cboPort.Size = new Size(84, 21);
        this.cboPort.TabIndex = 1;
        this.cboPort.Font = new Font("Microsoft YaHei UI", 6.5F, FontStyle.Regular, GraphicsUnit.Point);
        this.cboPort.DropDownStyle = ComboBoxStyle.DropDownList;
        this.cboPort.BackColor = Color.White;

        this.lblBaudRate.AutoSize = true;
        this.lblBaudRate.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblBaudRate.Location = new Point(147, 28);
        this.lblBaudRate.Size = new Size(46, 17);
        this.lblBaudRate.TabIndex = 2;
        this.lblBaudRate.Text = "波特率:";
        this.lblBaudRate.ForeColor = Color.FromArgb(80, 80, 80);

        this.cboBaudRate.Location = new Point(196, 25);
        this.cboBaudRate.Size = new Size(84, 21);
        this.cboBaudRate.TabIndex = 3;
        this.cboBaudRate.Font = new Font("Microsoft YaHei UI", 6.5F, FontStyle.Regular, GraphicsUnit.Point);
        this.cboBaudRate.DropDownStyle = ComboBoxStyle.DropDownList;
        this.cboBaudRate.Items.AddRange(new object[] { "9600", "19200", "38400", "57600", "115200", "230400", "460800" });
        this.cboBaudRate.SelectedIndex = 4;
        this.cboBaudRate.BackColor = Color.White;

        this.btnConnect.Location = new Point(294, 23);
        this.btnConnect.Size = new Size(70, 28);
        this.btnConnect.TabIndex = 4;
        this.btnConnect.Text = "连接";
        this.btnConnect.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnConnect.UseVisualStyleBackColor = false;
        this.btnConnect.Click += BtnConnect_Click;
        this.btnConnect.BackColor = Color.FromArgb(41, 128, 185);
        this.btnConnect.ForeColor = Color.White;
        this.btnConnect.FlatStyle = FlatStyle.Flat;
        this.btnConnect.FlatAppearance.BorderSize = 0;
        this.btnConnect.Cursor = Cursors.Hand;

        this.lblChannelCount.AutoSize = true;
        this.lblChannelCount.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblChannelCount.Location = new Point(378, 28);
        this.lblChannelCount.Size = new Size(54, 17);
        this.lblChannelCount.TabIndex = 5;
        this.lblChannelCount.Text = "通道数量:";
        this.lblChannelCount.ForeColor = Color.FromArgb(80, 80, 80);

        this.cboChannelCount.Location = new Point(439, 25);
        this.cboChannelCount.Size = new Size(56, 21);
        this.cboChannelCount.TabIndex = 6;
        this.cboChannelCount.Font = new Font("Microsoft YaHei UI", 6.5F, FontStyle.Regular, GraphicsUnit.Point);
        this.cboChannelCount.DropDownStyle = ComboBoxStyle.DropDownList;
        this.cboChannelCount.BackColor = Color.White;
        for (int i = 1; i <= 12; i++)
            this.cboChannelCount.Items.Add(i);
        this.cboChannelCount.SelectedIndex = 11;

        this.btnApplyConfig.Location = new Point(501, 23);
        this.btnApplyConfig.Size = new Size(56, 28);
        this.btnApplyConfig.TabIndex = 7;
        this.btnApplyConfig.Text = "应用";
        this.btnApplyConfig.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnApplyConfig.UseVisualStyleBackColor = false;
        this.btnApplyConfig.Click += BtnApplyConfig_Click;
        this.btnApplyConfig.BackColor = Color.FromArgb(46, 125, 50);
        this.btnApplyConfig.ForeColor = Color.White;
        this.btnApplyConfig.FlatStyle = FlatStyle.Flat;
        this.btnApplyConfig.FlatAppearance.BorderSize = 0;
        this.btnApplyConfig.Cursor = Cursors.Hand;

        this.btnSaveConfig.Location = new Point(564, 23);
        this.btnSaveConfig.Size = new Size(56, 28);
        this.btnSaveConfig.TabIndex = 8;
        this.btnSaveConfig.Text = "保存";
        this.btnSaveConfig.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnSaveConfig.UseVisualStyleBackColor = false;
        this.btnSaveConfig.Click += BtnSaveConfig_Click;
        this.btnSaveConfig.BackColor = Color.FromArgb(33, 150, 243);
        this.btnSaveConfig.ForeColor = Color.White;
        this.btnSaveConfig.FlatStyle = FlatStyle.Flat;
        this.btnSaveConfig.FlatAppearance.BorderSize = 0;
        this.btnSaveConfig.Cursor = Cursors.Hand;

        this.btnReadDeviceInfo.Location = new Point(627, 23);
        this.btnReadDeviceInfo.Size = new Size(80, 28);
        this.btnReadDeviceInfo.TabIndex = 9;
        this.btnReadDeviceInfo.Text = "读取设备信息";
        this.btnReadDeviceInfo.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnReadDeviceInfo.UseVisualStyleBackColor = false;
        this.btnReadDeviceInfo.Click += BtnReadDeviceInfo_Click;
        this.btnReadDeviceInfo.BackColor = Color.FromArgb(155, 89, 182);
        this.btnReadDeviceInfo.ForeColor = Color.White;
        this.btnReadDeviceInfo.FlatStyle = FlatStyle.Flat;
        this.btnReadDeviceInfo.FlatAppearance.BorderSize = 0;
        this.btnReadDeviceInfo.Cursor = Cursors.Hand;

        this.btnLoopTest.Location = new Point(713, 23);
        this.btnLoopTest.Size = new Size(80, 28);
        this.btnLoopTest.TabIndex = 10;
        this.btnLoopTest.Text = "环路测试";
        this.btnLoopTest.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnLoopTest.UseVisualStyleBackColor = false;
        this.btnLoopTest.Click += BtnLoopTest_Click;
        this.btnLoopTest.BackColor = Color.FromArgb(230, 126, 34);
        this.btnLoopTest.ForeColor = Color.White;
        this.btnLoopTest.FlatStyle = FlatStyle.Flat;
        this.btnLoopTest.FlatAppearance.BorderSize = 0;
        this.btnLoopTest.Cursor = Cursors.Hand;

        this.lblLoopTestStatus.AutoSize = true;
        this.lblLoopTestStatus.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblLoopTestStatus.Location = new Point(800, 30);
        this.lblLoopTestStatus.Size = new Size(60, 17);
        this.lblLoopTestStatus.TabIndex = 11;
        this.lblLoopTestStatus.Text = "测试状态";
        this.lblLoopTestStatus.ForeColor = Color.FromArgb(80, 80, 80);

        this.groupChannels.Controls.Add(this.flowPanelChannels);
        this.groupChannels.Location = new Point(11, 88);
        this.groupChannels.Size = new Size(2300, 856);
        this.groupChannels.TabIndex = 1;
        this.groupChannels.TabStop = false;
        this.groupChannels.Text = "烧录通道";
        this.groupChannels.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Bold, GraphicsUnit.Point);
        this.groupChannels.ForeColor = Color.FromArgb(60, 60, 60);

        this.flowPanelChannels.Dock = DockStyle.Fill;
        this.flowPanelChannels.AutoScroll = true;
        this.flowPanelChannels.Padding = new Padding(7);
        this.flowPanelChannels.BackColor = Color.Transparent;

        this.groupControls.Controls.Add(this.btnStartAll);
        this.groupControls.Controls.Add(this.btnBatchScanStart);
        this.groupControls.Controls.Add(this.btnStopAll);
        this.groupControls.Controls.Add(this.btnResetAll);
        this.groupControls.Controls.Add(this.btnTraceQuery);
        this.groupControls.Location = new Point(11, 642);
        this.groupControls.Size = new Size(2300, 118);
        this.groupControls.TabIndex = 2;
        this.groupControls.TabStop = false;
        this.groupControls.Text = "批量控制";
        this.groupControls.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Bold, GraphicsUnit.Point);
        this.groupControls.ForeColor = Color.FromArgb(60, 60, 60);

        this.btnStartAll.Location = new Point(14, 23);
        this.btnStartAll.Size = new Size(105, 30);
        this.btnStartAll.TabIndex = 0;
        this.btnStartAll.Text = "一键启动全部";
        this.btnStartAll.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnStartAll.UseVisualStyleBackColor = false;
        this.btnStartAll.Click += BtnStartAll_Click;
        this.btnStartAll.BackColor = Color.FromArgb(39, 174, 96);
        this.btnStartAll.ForeColor = Color.White;
        this.btnStartAll.FlatStyle = FlatStyle.Flat;
        this.btnStartAll.FlatAppearance.BorderSize = 0;
        this.btnStartAll.Cursor = Cursors.Hand;

        this.btnBatchScanStart.Location = new Point(130, 23);
        this.btnBatchScanStart.Size = new Size(105, 30);
        this.btnBatchScanStart.TabIndex = 1;
        this.btnBatchScanStart.Text = "批量扫码并启动";
        this.btnBatchScanStart.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnBatchScanStart.UseVisualStyleBackColor = false;
        this.btnBatchScanStart.Click += BtnBatchScanStart_Click;
        this.btnBatchScanStart.BackColor = Color.FromArgb(41, 128, 185);
        this.btnBatchScanStart.ForeColor = Color.White;
        this.btnBatchScanStart.FlatStyle = FlatStyle.Flat;
        this.btnBatchScanStart.FlatAppearance.BorderSize = 0;
        this.btnBatchScanStart.Cursor = Cursors.Hand;

        this.btnStopAll.Location = new Point(246, 23);
        this.btnStopAll.Size = new Size(105, 30);
        this.btnStopAll.TabIndex = 2;
        this.btnStopAll.Text = "全部停止";
        this.btnStopAll.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnStopAll.UseVisualStyleBackColor = false;
        this.btnStopAll.Click += BtnStopAll_Click;
        this.btnStopAll.BackColor = Color.FromArgb(230, 126, 34);
        this.btnStopAll.ForeColor = Color.White;
        this.btnStopAll.FlatStyle = FlatStyle.Flat;
        this.btnStopAll.FlatAppearance.BorderSize = 0;
        this.btnStopAll.Cursor = Cursors.Hand;

        this.btnResetAll.Location = new Point(362, 23);
        this.btnResetAll.Size = new Size(105, 30);
        this.btnResetAll.TabIndex = 3;
        this.btnResetAll.Text = "清空状态";
        this.btnResetAll.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnResetAll.UseVisualStyleBackColor = false;
        this.btnResetAll.Click += BtnResetAll_Click;
        this.btnResetAll.BackColor = Color.FromArgb(100, 100, 100);
        this.btnResetAll.ForeColor = Color.White;
        this.btnResetAll.FlatStyle = FlatStyle.Flat;
        this.btnResetAll.FlatAppearance.BorderSize = 0;
        this.btnResetAll.Cursor = Cursors.Hand;

        this.btnTraceQuery.Location = new Point(478, 23);
        this.btnTraceQuery.Size = new Size(105, 30);
        this.btnTraceQuery.TabIndex = 4;
        this.btnTraceQuery.Text = "二维码查询";
        this.btnTraceQuery.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnTraceQuery.UseVisualStyleBackColor = false;
        this.btnTraceQuery.Click += BtnTraceQuery_Click;
        this.btnTraceQuery.BackColor = Color.FromArgb(155, 89, 182);
        this.btnTraceQuery.ForeColor = Color.White;
        this.btnTraceQuery.FlatStyle = FlatStyle.Flat;
        this.btnTraceQuery.FlatAppearance.BorderSize = 0;
        this.btnTraceQuery.Cursor = Cursors.Hand;

        this.splitterPanel.Location = new Point(11, 768);
        this.splitterPanel.Size = new Size(2300, 6);
        this.splitterPanel.TabIndex = 4;
        this.splitterPanel.BackColor = Color.FromArgb(200, 200, 200);
        this.splitterPanel.Cursor = Cursors.HSplit;
        this.splitterPanel.MouseDown += SplitterPanel_MouseDown;
        this.splitterPanel.MouseMove += SplitterPanel_MouseMove;
        this.splitterPanel.MouseUp += SplitterPanel_MouseUp;
        this.splitterPanel.MouseEnter += SplitterPanel_MouseEnter;
        this.splitterPanel.MouseLeave += SplitterPanel_MouseLeave;

        this.groupLog.Controls.Add(this.txtLog);
        this.groupLog.Location = new Point(11, 780);
        this.groupLog.Size = new Size(2300, 510);
        this.groupLog.TabIndex = 3;
        this.groupLog.TabStop = false;
        this.groupLog.Text = "日志";
        this.groupLog.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Bold, GraphicsUnit.Point);
        this.groupLog.ForeColor = Color.FromArgb(60, 60, 60);

        this.txtLog.Dock = DockStyle.Fill;
        this.txtLog.TabIndex = 0;
        this.txtLog.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.txtLog.ReadOnly = true;
        this.txtLog.Multiline = true;
        this.txtLog.ScrollBars = RichTextBoxScrollBars.Vertical;
        this.txtLog.BackColor = Color.FromArgb(245, 245, 245);
        this.txtLog.ForeColor = Color.FromArgb(60, 60, 60);
        this.txtLog.BorderStyle = BorderStyle.None;
        this.txtLog.Padding = new Padding(5);

        this.splitterPanel.ResumeLayout(false);
        this.groupLog.ResumeLayout(false);
        this.AutoScaleDimensions = new SizeF(7F, 17F);
        this.AutoScaleMode = AutoScaleMode.Font;
        this.ClientSize = new Size(1880, 1300);
        this.Controls.Add(this.groupControls);
        this.Controls.Add(this.splitterPanel);
        this.Controls.Add(this.groupLog);
        this.Controls.Add(this.groupChannels);
        this.Controls.Add(this.groupSerial);
        this.Name = "Form1";
        this.Text = "1拖12烧录上位机";
        this.Font = new Font("Microsoft YaHei UI", 6.5F, FontStyle.Regular, GraphicsUnit.Point);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.FormBorderStyle = FormBorderStyle.Sizable;
        this.MaximizeBox = true;
        this.Resize += Form1_Resize;

        this.groupSerial.ResumeLayout(false);
        this.groupSerial.PerformLayout();
        this.groupChannels.ResumeLayout(false);
        this.groupControls.ResumeLayout(false);
        this.ResumeLayout(false);
    }

    private void SplitterPanel_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            isDragging = true;
            Cursor = Cursors.HSplit;
        }
    }

    private void SplitterPanel_MouseMove(object? sender, MouseEventArgs e)
    {
        if (isDragging)
        {
            int newY = e.Y + splitterPanel.Top;
            int minY = groupChannels.Top + MinChannelAreaHeight + 7 + groupControls.Height + splitterPanel.Height;
            int maxY = ClientSize.Height - MinLogAreaHeight - splitterPanel.Height - 17;

            newY = Math.Max(minY, Math.Min(newY, maxY));

            int requestedLogHeight = ClientSize.Height - (newY + splitterPanel.Height + 6) - 11;
            UpdateMainLayout(requestedLogHeight);
        }
    }

    private void SplitterPanel_MouseUp(object? sender, MouseEventArgs e)
    {
        isDragging = false;
        Cursor = Cursors.Default;
    }

    private void SplitterPanel_MouseEnter(object? sender, EventArgs e)
    {
        if (!isDragging)
        {
            splitterPanel.BackColor = Color.FromArgb(150, 150, 150);
        }
    }

    private void SplitterPanel_MouseLeave(object? sender, EventArgs e)
    {
        if (!isDragging)
        {
            splitterPanel.BackColor = Color.FromArgb(200, 200, 200);
        }
    }

    private void Form1_Resize(object? sender, EventArgs e)
    {
        if (groupLog != null && splitterPanel != null)
        {
            UpdateMainLayout();
        }
    }

    private void UpdateMainLayout(int? requestedLogHeight = null)
    {
        int contentWidth = ClientSize.Width - 22;
        int maxLogAreaHeight = ClientSize.Height - (groupChannels.Top + MinChannelAreaHeight + 7 + groupControls.Height + 6 + splitterPanel.Height + 6 + 11);
        maxLogAreaHeight = Math.Max(MinLogAreaHeight, maxLogAreaHeight);

        int targetLogHeight = requestedLogHeight ?? lastLogAreaHeight;
        targetLogHeight = Math.Max(MinLogAreaHeight, Math.Min(targetLogHeight, maxLogAreaHeight));
        lastLogAreaHeight = targetLogHeight;

        groupSerial.Size = new Size(contentWidth, groupSerial.Height);

        groupLog.Location = new Point(11, ClientSize.Height - targetLogHeight - 11);
        groupLog.Size = new Size(contentWidth, targetLogHeight);

        splitterPanel.Location = new Point(11, groupLog.Top - splitterPanel.Height - 6);
        splitterPanel.Size = new Size(contentWidth, splitterPanel.Height);

        groupControls.Location = new Point(11, splitterPanel.Top - groupControls.Height - 6);
        groupControls.Size = new Size(contentWidth, groupControls.Height);

        groupChannels.Size = new Size(contentWidth, groupControls.Top - 7 - groupChannels.Top);
    }
}
