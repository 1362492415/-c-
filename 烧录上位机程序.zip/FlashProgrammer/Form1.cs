using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace FlashProgrammer;

public partial class Form1 : Form
{
    private SerialCommunicator? serialComm;
    private Logger? _logger;
    private TraceabilityRepository? _traceabilityRepository;
    private readonly Dictionary<int, BurnTraceContext> _traceContexts = new Dictionary<int, BurnTraceContext>();
    private readonly Dictionary<int, string> _latestDeviceInfoByChannel = new Dictionary<int, string>();
    private readonly Dictionary<int, string> _latestFirmwareNameByChannel = new Dictionary<int, string>();
    private readonly CancellationTokenSource?[] _progressPollingCts = new CancellationTokenSource?[12];
    private volatile ushort _lastProgressQueryChannel = 1;
    private bool _handshakeCompleted = false;  // 握手是否完成标志
    private CancellationTokenSource? _handshakeCts;
    private TaskCompletionSource<bool>? _handshakeResponseTcs;
    private string? _currentBatchId;
    private CheckBox? _chkAutoNextBatchScan;
    private bool _isOpeningNextBatchScan;
    private const int HandshakeTimeoutMs = 3000;
    private const int HandshakeRetryCount = 3;
    private const int HandshakeInitialDelayMs = 500;
    
    public Form1()
    {
        InitializeComponent();
        FormDisplayHelper.FitToWorkingArea(this, new Size(1880, 1300), new Size(1180, 650));
        InitializeBatchModeOption();
        Shown += Form1_Shown;
        _logger = new Logger(LogToUi);
        InitializeConfig();
        InitializeTraceability();
        InitializeSerial();
        InitializeChannels();
        _logger.Info("程序启动");
    }

    private void Form1_Shown(object? sender, EventArgs e)
    {
        // 首次显示时主动执行一次布局修正，避免必须手动拉伸窗口后底部区域才出现
        BeginInvoke(new Action(() => Form1_Resize(this, EventArgs.Empty)));
    }
    
    private void InitializeConfig()
    {
        config = AppConfig.Load();
        cboChannelCount.SelectedIndex = config.EnabledChannels - 1;
        if (_chkAutoNextBatchScan != null)
        {
            _chkAutoNextBatchScan.Checked = config.AutoOpenNextBatchScanAfterComplete;
        }
        if (!string.IsNullOrEmpty(config.DefaultPort))
        {
            var index = cboPort.Items.IndexOf(config.DefaultPort);
            if (index >= 0)
                cboPort.SelectedIndex = index;
        }
    }
    
    private void InitializeSerial()
    {
        serialComm = new SerialCommunicator();
        // 订阅数据包接收事件
        serialComm.PacketReceived += OnPacketReceived;
        // 订阅原始数据事件（用于调试）
        serialComm.RawDataReceived += OnRawDataReceived;
        
        RefreshPorts();
        cboPort.Click += (s, e) => RefreshPorts();
    }
    
    private void RefreshPorts()
    {
        var selectedPort = cboPort.SelectedItem?.ToString();
        cboPort.Items.Clear();
        string[] ports = SerialPort.GetPortNames();
        cboPort.Items.AddRange(ports);
        
        if (!string.IsNullOrEmpty(selectedPort))
        {
            var index = cboPort.Items.IndexOf(selectedPort);
            if (index >= 0)
                cboPort.SelectedIndex = index;
        }
        else if (cboPort.Items.Count > 0)
        {
            cboPort.SelectedIndex = 0;
        }
    }

    private void InitializeTraceability()
    {
        try
        {
            _traceabilityRepository = new TraceabilityRepository(config.TraceabilityConnectionString, _logger);
            _traceabilityRepository.Initialize();
            _logger?.Info("追溯数据库初始化完成，当前已连接到 SQL Server。");
            btnTraceQuery.Enabled = true;
        }
        catch (Exception ex)
        {
            _traceabilityRepository = null;
            btnTraceQuery.Enabled = false;
            _logger?.Error("追溯数据库初始化失败", ex);
        }
    }
    
    private void InitializeChannels()
    {
        CreateChannels(config.EnabledChannels);
    }
    
    private void CreateChannels(int count)
    {
        flowPanelChannels.Controls.Clear();
        channelControls = new ChannelControl[count];
        _traceContexts.Clear();
        _latestDeviceInfoByChannel.Clear();
        _latestFirmwareNameByChannel.Clear();
        _currentBatchId = null;
        
        for (int i = 0; i < count; i++)
        {
            var channel = new ChannelControl();
            channel.Initialize(i + 1);
            channel.Size = new Size(372, 340);
            channel.Margin = new Padding(3);
            channel.StartButtonClicked += Channel_StartButtonClicked;
            channel.ScanButtonClicked += Channel_ScanButtonClicked;
            flowPanelChannels.Controls.Add(channel);
            channelControls[i] = channel;
        }
    }
    

private void Channel_StartButtonClicked(object? sender, EventArgs e)
{
    try
    {
        if (sender is not ChannelControl channel)
            return;

        if (serialComm == null || !serialComm.IsOpen)
        {
            MessageBox.Show("请先连接串口！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _logger?.Error($"通道 {channel.ChannelNumber} 启动失败: 串口未连接");
            return;
        }

        // 检查是否已完成握手
        if (!_handshakeCompleted)
        {
            MessageBox.Show("设备未完成握手，请先等待握手完成或重新连接！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _logger?.Error($"通道 {channel.ChannelNumber} 启动失败: 设备未握手");
            return;
        }

        if (channel.CurrentStatus != ChannelStatus.Waiting && channel.CurrentStatus != ChannelStatus.Failed)
        {
            MessageBox.Show($"通道 {channel.ChannelNumber} 当前状态不允许启动！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _logger?.Warning($"通道 {channel.ChannelNumber} 启动失败: 当前状态为 {channel.CurrentStatus}");
            return;
        }

        ushort currentChannel = (ushort)channel.ChannelNumber;
        ushort startTarget = BuildStartTargetForCurrentMode(channel.ChannelNumber);

        // 新一轮烧录开始前，先清掉上一次的最终态，避免后续进度包被锁定忽略。
        channel.UpdateStatus(ChannelStatus.Waiting, 0);
        StopProgressPolling(currentChannel);

        bool sendSuccess = serialComm.SendStartProgram(startTarget);
        if (sendSuccess)
        {
            BeginTraceForChannel(channel.ChannelNumber, false);
            RequestCurrentFirmwareName(channel.ChannelNumber);
            if (IsMultiChannelMode())
            {
                _logger?.Info($"通道 {currentChannel} 发送启动烧录指令成功: mask=0x{startTarget:X4}");
            }
            else
            {
                _logger?.Info($"通道 {currentChannel} 发送启动烧录指令成功");
            }
        }
        else
        {
            _logger?.Error($"通道 {currentChannel} 发送启动烧录指令失败");
            MessageBox.Show($"通道 {currentChannel} 发送命令失败，请检查串口连接！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    catch (Exception ex)
    {
        _logger?.Error($"通道启动烧录异常: {ex.Message}");
        MessageBox.Show($"启动烧录异常: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

private static bool IsFinalChannelStatus(ChannelStatus status)
{
    return status == ChannelStatus.Success || status == ChannelStatus.Failed;
}

private static ushort BuildChannelMask(int channelCount)
{
    if (channelCount <= 0)
        return 0;

    int effectiveChannelCount = Math.Min(channelCount, 12);
    return (ushort)((1 << effectiveChannelCount) - 1);
}

private bool IsEightChannelMode()
{
    return channelControls?.Length == 8;
}

private bool IsMultiChannelMode()
{
    int activeChannelCount = channelControls?.Length ?? 0;
    return activeChannelCount > 1;
}

private ushort BuildSingleChannelMask(int channelNumber)
{
    if (channelNumber < 1 || channelNumber > 16)
        return 0;

    return (ushort)(1 << (channelNumber - 1));
}

private ushort BuildStartTargetForCurrentMode(int channelNumber)
{
    if (!IsMultiChannelMode())
        return 0;

    return BuildSingleChannelMask(channelNumber);
}

private void InitializeBatchModeOption()
{
    _chkAutoNextBatchScan = new CheckBox
    {
        Text = "烧录完成后自动进入下一批扫码",
        Location = new Point(18, 66),
        Size = new Size(320, 28),
        Font = new Font("Microsoft YaHei UI", 8F, FontStyle.Regular, GraphicsUnit.Point),
        AutoSize = false
    };
    groupControls.Controls.Add(_chkAutoNextBatchScan);
}

private void BeginTraceForChannel(int channelNumber, bool isBatch)
{
    if (channelNumber < 1 || channelControls == null || channelNumber > channelControls.Length)
        return;

    string? qrCode = channelControls[channelNumber - 1].QRCodeData;
    if (string.IsNullOrWhiteSpace(qrCode))
    {
        _traceContexts.Remove(channelNumber);
        _logger?.Warning($"通道 {channelNumber} 未绑定二维码，本次烧录不写入追溯记录");
        return;
    }

    _traceContexts[channelNumber] = new BurnTraceContext
    {
        ChannelNumber = channelNumber,
        QrCode = qrCode.Trim(),
        StartTime = DateTime.Now,
        DeviceInfo = _latestDeviceInfoByChannel.TryGetValue(channelNumber, out string? deviceInfo) ? deviceInfo : null,
        FirmwareName = _latestFirmwareNameByChannel.TryGetValue(channelNumber, out string? firmwareName) && !string.IsNullOrWhiteSpace(firmwareName)
            ? firmwareName
            : (string.IsNullOrWhiteSpace(config.DefaultFirmwareName) ? null : config.DefaultFirmwareName),
        PortName = cboPort.SelectedItem?.ToString(),
        BatchId = isBatch ? _currentBatchId : null,
        IsBatch = isBatch,
        RecordSaved = false
    };
}

private void BeginTraceForAllChannels(bool isBatch)
{
    for (int i = 1; i <= channelControls.Length; i++)
    {
        BeginTraceForChannel(i, isBatch);
    }
}

private void RequestCurrentFirmwareName(int channelNumber)
{
    if (serialComm == null || !serialComm.IsOpen)
        return;

    if (channelNumber < 1 || channelControls == null || channelNumber > channelControls.Length)
        return;

    bool sendSuccess = serialComm.SendQueryFileName((ushort)channelNumber);
    if (sendSuccess)
    {
        _logger?.Debug($"已发送当前烧录文件名查询: 通道={channelNumber}");
    }
    else
    {
        _logger?.Warning($"发送当前烧录文件名查询失败: 通道={channelNumber}");
    }
}

private void RequestCurrentFirmwareNameForAllChannels()
{
    if (channelControls == null)
        return;

    for (int i = 1; i <= channelControls.Length; i++)
    {
        RequestCurrentFirmwareName(i);
    }
}

    private string? GetQrCodeValidationError(string qrCodeContent, int? currentChannelNumber = null)
    {
        string qrCode = qrCodeContent.Trim();
        if (string.IsNullOrWhiteSpace(qrCode))
        {
            return "二维码内容不能为空";
        }

        if (_traceabilityRepository != null && _traceabilityRepository.HasSuccessfulRecord(qrCode))
        {
            return $"二维码已存在成功烧录记录，不能重复投产：{qrCode}";
        }

        if (channelControls == null)
        {
            return null;
        }

        for (int i = 0; i < channelControls.Length; i++)
        {
            int channelNumber = i + 1;
            if (currentChannelNumber.HasValue && channelNumber == currentChannelNumber.Value)
            {
                continue;
            }

            if (string.Equals(channelControls[i].QRCodeData, qrCode, StringComparison.OrdinalIgnoreCase))
            {
                return $"二维码已录入通道 {channelNumber}，请更换新的二维码";
            }
        }

        return null;
    }

private void TrySaveBurnRecord(int channelNumber, byte statusCode, string result, string statusText, string? errorMessage = null)
{
    if (_traceabilityRepository == null)
        return;

    if (!_traceContexts.TryGetValue(channelNumber, out BurnTraceContext? context))
        return;

    if (context.RecordSaved || string.IsNullOrWhiteSpace(context.QrCode))
        return;

    DateTime endTime = DateTime.Now;
    long durationMs = Math.Max(0, (long)(endTime - context.StartTime).TotalMilliseconds);

    var record = new BurnRecord
    {
        QrCode = context.QrCode,
        ChannelNumber = context.ChannelNumber,
        Result = result,
        StatusCode = $"0x{statusCode:X2}",
        StatusText = statusText,
        StartTime = context.StartTime,
        EndTime = endTime,
        DurationMs = durationMs,
        DeviceInfo = context.DeviceInfo,
        FirmwareName = context.FirmwareName,
        PortName = context.PortName,
        BatchId = context.BatchId,
        ErrorMessage = errorMessage,
        IsBatch = context.IsBatch
    };

    try
    {
        _traceabilityRepository.SaveRecord(record);
        context.RecordSaved = true;
        _logger?.Info($"追溯记录已保存: 通道={channelNumber}, 二维码={context.QrCode}, 结果={result}, 状态={record.StatusCode}");
    }
    catch (Exception ex)
    {
        _logger?.Error($"保存追溯记录失败: 通道={channelNumber}, 二维码={context.QrCode}", ex);
    }
}

private void TryHandleBatchCompletionAfterFinalStatus()
{
    if (string.IsNullOrWhiteSpace(_currentBatchId) || channelControls == null || _isOpeningNextBatchScan)
        return;

    if (!channelControls.All(c => IsFinalChannelStatus(c.CurrentStatus)))
        return;

    string completedBatchId = _currentBatchId;
    _currentBatchId = null;
    _logger?.Info($"批量烧录已完成: 批次={completedBatchId}");

    if (_chkAutoNextBatchScan?.Checked == true)
    {
        _isOpeningNextBatchScan = true;
        BeginInvoke(new Action(() =>
        {
            try { BtnBatchScanStart_Click(this, EventArgs.Empty); }
            finally { _isOpeningNextBatchScan = false; }
        }));
        return;
    }

    MessageBox.Show("本批烧录已完成，请取出产品并放入下一批，然后点击“批量扫码并启动”。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
}

private static string GetStatusText(ProgramStatus status)
{
    return status switch
    {
        ProgramStatus.ReadComplete => "读取完成",
        ProgramStatus.InitComplete => "初始化完成",
        ProgramStatus.ProtectionRemoved => "解除读保护成功",
        ProgramStatus.Erasing => "擦除中",
        ProgramStatus.EraseComplete => "擦除完成",
        ProgramStatus.Programming => "烧录中",
        ProgramStatus.ProgramComplete => "烧录完成",
        ProgramStatus.Verifying => "校验中",
        ProgramStatus.VerifyComplete => "校验完成",
        ProgramStatus.ConnectFailed => "连接失败",
        ProgramStatus.EraseFailed => "擦除失败",
        ProgramStatus.ProgramFailed => "烧录失败",
        ProgramStatus.VerifyFailed => "校验失败",
        ProgramStatus.ProgramCountExhausted => "烧录次数耗尽",
        ProgramStatus.VoltageError => "设备电压异常",
        _ => "未知状态"
    };
}

private static string BuildBatchId()
{
    return DateTime.Now.ToString("yyyyMMdd-HHmmss-fff");
}

private void StartProgressPolling(ushort channelNumber)
{
    if (serialComm == null || !serialComm.IsOpen)
        return;

    if (channelNumber < 1 || channelNumber > _progressPollingCts.Length)
        return;

    var cts = new CancellationTokenSource();
    _progressPollingCts[channelNumber - 1] = cts;

    _ = Task.Run(async () =>
    {
        try
        {
            while (!cts.IsCancellationRequested)
            {
                _lastProgressQueryChannel = channelNumber;
                serialComm.SendQueryProgress(channelNumber);
                await Task.Delay(500, cts.Token);
            }
        }
        catch (TaskCanceledException)
        {
        }
        catch (Exception ex)
        {
            Console.WriteLine($"进度轮询异常: {ex.Message}");
        }
    }, cts.Token);
}

private void StopProgressPolling(ushort channelNumber)
{
    if (channelNumber < 1 || channelNumber > _progressPollingCts.Length)
        return;

    var cts = _progressPollingCts[channelNumber - 1];
    _progressPollingCts[channelNumber - 1] = null;

    try
    {
        cts?.Cancel();
        cts?.Dispose();
    }
    catch
    {
    }
}
    
    private void ResetConnectionUi()
    {
        btnConnect.Text = "连接";
        btnConnect.BackColor = Color.FromArgb(41, 128, 185);
        _handshakeCompleted = false;
    }

    private void SetConnectedUi()
    {
        btnConnect.Text = "断开";
        btnConnect.BackColor = Color.FromArgb(231, 76, 60);
    }

    private void CancelHandshakeFlow()
    {
        _handshakeResponseTcs = null;

        var cts = _handshakeCts;
        _handshakeCts = null;
        if (cts == null)
            return;

        try
        {
            cts.Cancel();
        }
        catch
        {
        }
        finally
        {
            cts.Dispose();
        }
    }

    private async Task<bool> PerformHandshakeAsync(string portName, CancellationToken token)
    {
        if (serialComm == null)
            return false;

        // 某些下位机在串口打开后会因 DTR/RTS 拉起而短暂复位，先等设备稳定再发握手。
        await Task.Delay(HandshakeInitialDelayMs, token);

        for (int attempt = 1; attempt <= HandshakeRetryCount; attempt++)
        {
            token.ThrowIfCancellationRequested();

            if (!serialComm.IsOpen)
                return false;

            var responseTcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            _handshakeResponseTcs = responseTcs;

            if (!serialComm.SendHandshake())
            {
                _handshakeResponseTcs = null;
                _logger?.Warning($"串口 {portName} 第 {attempt} 次发送握手失败");
                continue;
            }

            _logger?.Info($"串口 {portName} 已连接，正在等待设备握手... ({attempt}/{HandshakeRetryCount})");

            Task completedTask = await Task.WhenAny(responseTcs.Task, Task.Delay(HandshakeTimeoutMs, token));
            if (completedTask == responseTcs.Task)
            {
                _handshakeResponseTcs = null;
                return await responseTcs.Task;
            }

            _handshakeResponseTcs = null;
            _logger?.Warning($"串口 {portName} 握手超时，第 {attempt} 次等待 {HandshakeTimeoutMs}ms 未收到响应");
        }

        return false;
    }

    private async void BtnConnect_Click(object? sender, EventArgs e)
    {
        if (serialComm == null) return;
        
        if (serialComm.IsOpen)
        {
            CancelHandshakeFlow();
            serialComm.ClosePort();
            ResetConnectionUi();
        }
        else
        {
            if (cboPort.SelectedItem == null)
            {
                MessageBox.Show("请选择串口！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            try
            {
                int baudRate = int.Parse(cboBaudRate.SelectedItem?.ToString() ?? "115200");
                string portName = cboPort.SelectedItem.ToString()!;
                bool success = serialComm.OpenPort(portName, baudRate);
                if (success)
                {
                    SetConnectedUi();
                    _handshakeCompleted = false;

                    CancelHandshakeFlow();
                    var handshakeCts = new CancellationTokenSource();
                    _handshakeCts = handshakeCts;

                    try
                    {
                        bool handshakeSuccess = await PerformHandshakeAsync(portName, handshakeCts.Token);
                        if (!handshakeSuccess && !_handshakeCompleted)
                        {
                            serialComm.ClosePort();
                            ResetConnectionUi();
                            MessageBox.Show("设备握手超时，未收到响应！\n请检查：\n1. 设备是否上电并完成启动\n2. 串口线是否连接正确\n3. 波特率是否与下位机一致", 
                                "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (OperationCanceledException)
                    {
                    }
                    finally
                    {
                        if (ReferenceEquals(_handshakeCts, handshakeCts))
                        {
                            _handshakeCts = null;
                        }
                        handshakeCts.Dispose();
                    }
                }
                else
                {
                    MessageBox.Show("打开串口失败", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"打开串口失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    
    /// <summary>
    /// 处理接收到的协议数据包
    /// </summary>
    private void OnPacketReceived(object? sender, PacketReceivedEventArgs e)
    {
        if (channelControls == null) return;

        this.Invoke((MethodInvoker)delegate
        {
            ProtocolPacket packet = e.Packet;

            if (packet.Header == FrameHeader.HandshakeResponse)
            {
                HandleHandshakeResponse(packet);
                return;
            }

            ushort channelNumber = packet.Number;

            if (packet.Header == FrameHeader.ProgressResponse)
            {
                // 根据协议文档：
                // D2编号字段：单通道：首字节状态码、次字节进度；多通道：首字节通道号，次字节状态码。
                // 编号字段是2字节，小端序存储
                
                byte lowByte = (byte)(packet.Number & 0xFF);
                byte highByte = (byte)((packet.Number >> 8) & 0xFF);
                
                bool isMultiChannelMode = IsMultiChannelMode();

                // 判断是单通道还是多通道模式
                // 单通道：低字节是状态码(0x11-0xFF)，高字节是进度(0-100)
                // 多通道：低字节 0x00~0x(N-1) 依次表示通道 1~N，高字节是状态码

                if (isMultiChannelMode && lowByte < channelControls.Length && highByte >= 0x11)
                {
                    channelNumber = (ushort)(lowByte + 1);
                    _logger?.Debug($"进度响应(多通道-0基协议): 原始通道=0x{lowByte:X2}, 映射通道={channelNumber}, 状态码=0x{highByte:X2}");
                }
                else if (!isMultiChannelMode && lowByte == 0 && highByte >= 0x11)
                {
                    _logger?.Debug($"进度响应(汇总): 状态码=0x{highByte:X2}");
                    return;
                }
                else if (!isMultiChannelMode && lowByte >= 1 && lowByte <= channelControls.Length && highByte >= 0x11)
                {
                    channelNumber = lowByte;
                    _logger?.Debug($"进度响应(多通道): 通道={channelNumber}, 状态码=0x{highByte:X2}");
                }
                else if (lowByte >= 0x11 && lowByte <= 0xFF)
                {
                    if (_lastProgressQueryChannel > 0 && _lastProgressQueryChannel <= channelControls.Length)
                    {
                        channelNumber = _lastProgressQueryChannel;
                    }
                    _logger?.Debug($"进度响应(单通道): 通道={channelNumber}, 状态码=0x{lowByte:X2}, 进度={highByte}%");
                }
                else if (channelNumber < 1 || channelNumber > channelControls.Length)
                {
                    _logger?.Debug($"进度响应(通道超出范围): 原始编号=0x{packet.Number:X4}");
                    return; // 超出范围直接丢弃，不要猜测通道，防止误更新
                }
            }

            int channelIndex = channelNumber - 1;
            if (channelIndex < 0 || channelIndex >= channelControls.Length)
                return;

            ChannelControl channel = channelControls[channelIndex];

            switch (packet.Header)
            {
                case FrameHeader.ProgressResponse:
                    HandleProgressResponse(packet, channel);
                    break;

                case FrameHeader.DeviceIdResponse:
                    HandleDeviceIdResponse(packet, channel);
                    break;

                case FrameHeader.DeviceInfoResponse:
                    HandleDeviceInfoResponse(packet, channel);
                    break;

                case FrameHeader.FileNameResponse:
                    HandleFileNameResponse(packet, channel);
                    break;

                case FrameHeader.ErrorReport:
                    HandleErrorResponse(packet, channel);
                    StopProgressPolling((ushort)channel.ChannelNumber);
                    break;

                case FrameHeader.ProgramConfirm:
                    HandleProgramConfirm(packet, channel);
                    break;

                case FrameHeader.FirmwareComplete:
                    HandleFirmwareComplete(packet, channel);
                    break;

                case FrameHeader.ProgramComplete:
                    HandleProgramComplete(packet, channel);
                    StopProgressPolling((ushort)channel.ChannelNumber);
                    break;

                case FrameHeader.EraseConfirm:
                    HandleEraseConfirm(packet, channel);
                    break;
            }
        });
    }
    
    /// <summary>
    /// 处理进度响应包
    /// </summary>
    private void HandleProgressResponse(ProtocolPacket packet, ChannelControl channel)
    {
        int activeChannelCount = channelControls?.Length ?? 1;

        if (ProtocolUnpacker.ParseProgressPacket(packet, out ProgramStatus status, out int progress, activeChannelCount))
        {
        if (IsFinalChannelStatus(channel.CurrentStatus))
        {
            _logger?.Debug($"忽略通道 {channel.ChannelNumber} 的后续进度状态 0x{(byte)status:X2}，当前状态已锁定为 {channel.CurrentStatus}");
            return;
        }

            switch (status)
            {
                case ProgramStatus.ReadComplete:
                case ProgramStatus.InitComplete:
                case ProgramStatus.ProtectionRemoved:
                    channel.UpdateStatus(ChannelStatus.Waiting, progress);
                    break;

                case ProgramStatus.Erasing:
                    channel.UpdateStatus(ChannelStatus.Erasing, progress);
                    break;

                case ProgramStatus.EraseComplete:
                    channel.UpdateStatus(ChannelStatus.Waiting, 100);
                    break;

                case ProgramStatus.Programming:
                    channel.UpdateStatus(ChannelStatus.Programming, progress);
                    break;

                case ProgramStatus.ProgramComplete:
                    channel.UpdateStatus(ChannelStatus.Success, 100);
                    TrySaveBurnRecord(channel.ChannelNumber, (byte)status, "Success", GetStatusText(status));
                    TryHandleBatchCompletionAfterFinalStatus();
                    break;

                case ProgramStatus.Verifying:
                    channel.UpdateStatus(ChannelStatus.Programming, progress);
                    break;

                case ProgramStatus.VerifyComplete:
                    channel.UpdateStatus(ChannelStatus.Success, 100);
                    TrySaveBurnRecord(channel.ChannelNumber, (byte)status, "Success", GetStatusText(status));
                    StopProgressPolling((ushort)channel.ChannelNumber);
                    TryHandleBatchCompletionAfterFinalStatus();
                    break;

                case ProgramStatus.ConnectFailed:
                case ProgramStatus.EraseFailed:
                case ProgramStatus.ProgramFailed:
                case ProgramStatus.VerifyFailed:
                case ProgramStatus.ProgramCountExhausted:
                case ProgramStatus.VoltageError:
                    channel.UpdateStatus(ChannelStatus.Failed, 0);
                    TrySaveBurnRecord(channel.ChannelNumber, (byte)status, "Failed", GetStatusText(status), GetStatusText(status));
                    StopProgressPolling((ushort)channel.ChannelNumber);
                    TryHandleBatchCompletionAfterFinalStatus();
                    break;
            }
        }
    }
    
    /// <summary>
    /// 处理设备ID响应包
    /// </summary>
    private void HandleDeviceIdResponse(ProtocolPacket packet, ChannelControl channel)
    {
        string deviceId = ProtocolUnpacker.ParseDeviceIdPacket(packet);
        // 可以在这里显示设备ID信息
        Console.WriteLine($"通道 {packet.Number} 设备ID: {deviceId}");
    }
    
    /// <summary>
    /// 处理设备信息响应包
    /// </summary>
    private void HandleDeviceInfoResponse(ProtocolPacket packet, ChannelControl channel)
    {
        string deviceInfo = ProtocolUnpacker.ParseDeviceInfoPacket(packet);
        _latestDeviceInfoByChannel[channel.ChannelNumber] = deviceInfo;
        if (_traceContexts.TryGetValue(channel.ChannelNumber, out BurnTraceContext? context))
        {
            context.DeviceInfo = deviceInfo;
        }

        _logger?.Info($"通道 {packet.Number} 设备信息: {deviceInfo}");
        
        // 检查设备信息是否包含二维码数据（包含 QR 或 SN 关键字）
        if (deviceInfo.Contains("QR") || deviceInfo.Contains("SN"))
        {
            // 尝试从二维码内容中解析通道号
            if (QrCodeScanner.ParseQrCodeContent(deviceInfo, out int parsedChannel, out string productInfo))
            {
                // 解析成功
                if (parsedChannel >= 1 && parsedChannel <= channelControls.Length)
                {
                    var targetChannel = channelControls[parsedChannel - 1];
                    
                    // 手持扫码优先：只有当通道还没有二维码时才从串口更新
                    if (string.IsNullOrEmpty(targetChannel.QRCodeData))
                    {
                        targetChannel.UpdateQRCodeByText(deviceInfo);
                        _logger?.Info($"通道 {parsedChannel} 二维码已更新（串口接收）: {deviceInfo}");
                    }
                    else
                    {
                        _logger?.Info($"通道 {parsedChannel} 已有二维码（扫码枪录入），跳过串口更新");
                    }
                }
            }
            else
            {
                // 无法解析通道号，不显示，等待扫码枪按通道录入
                _logger?.Warning($"无法解析二维码通道号: {deviceInfo}，请使用扫码枪按通道录入");
            }
        }
    }

    /// <summary>
    /// 处理当前烧录文件名响应包
    /// </summary>
    private void HandleFileNameResponse(ProtocolPacket packet, ChannelControl channel)
    {
        string firmwareName = ProtocolUnpacker.ParseFileNamePacket(packet);
        if (string.IsNullOrWhiteSpace(firmwareName))
        {
            _logger?.Warning($"通道 {channel.ChannelNumber} 返回的当前烧录文件名为空");
            return;
        }

        _latestFirmwareNameByChannel[channel.ChannelNumber] = firmwareName;
        if (_traceContexts.TryGetValue(channel.ChannelNumber, out BurnTraceContext? context))
        {
            context.FirmwareName = firmwareName;
        }

        _logger?.Info($"通道 {channel.ChannelNumber} 当前烧录文件名: {firmwareName}");
    }
    
    private void Channel_ScanButtonClicked(object? sender, EventArgs e)
    {
        if (sender is not ChannelControl channel) return;
        int channelNumber = channel.ChannelNumber;

        // 创建扫码对话框
        using (var scanForm = new ScanForm())
        {
            scanForm.Text = $"扫描二维码 - 通道 {channelNumber}";
            if (scanForm.ShowDialog() == DialogResult.OK)
            {
                string qrCodeContent = scanForm.QrCodeContent;
                ProcessScannedQrCodeForChannel(channelNumber, qrCodeContent);
            }
        }
    }

    private void ProcessScannedQrCodeForChannel(int channelNumber, string qrCodeContent)
    {
        if (channelNumber >= 1 && channelNumber <= channelControls.Length)
        {
            string? validationError = GetQrCodeValidationError(qrCodeContent, channelNumber);
            if (!string.IsNullOrWhiteSpace(validationError))
            {
                MessageBox.Show(validationError, "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _logger?.Warning($"通道 {channelNumber} 二维码录入被拒绝: {validationError}");
                return;
            }

            channelControls[channelNumber - 1].UpdateQRCodeByText(qrCodeContent.Trim());
            if (_traceContexts.TryGetValue(channelNumber, out BurnTraceContext? context))
            {
                context.QrCode = qrCodeContent.Trim();
            }
            _logger?.Info($"通道 {channelNumber} 二维码已更新（扫码枪扫描）: {qrCodeContent.Trim()}");
        }
    }
    
    private void QrScanner_ScanError(object? sender, string e)
    {
        _logger?.Error("扫码错误: " + e);
    }
    
    private void QrScanner_CameraStateChanged(object? sender, bool e)
    {
        _logger?.Info(e ? "摄像头已启动" : "摄像头已停止");
    }
    
    /// <summary>
    /// 处理错误报告包
    /// </summary>
    private void HandleErrorResponse(ProtocolPacket packet, ChannelControl channel)
    {
        string errorMessage = ProtocolUnpacker.ParseErrorPacket(packet);
        channel.UpdateStatus(ChannelStatus.Failed, 0);
        TrySaveBurnRecord(channel.ChannelNumber, (byte)FrameHeader.ErrorReport, "Failed", "错误报告", errorMessage);
        TryHandleBatchCompletionAfterFinalStatus();
        MessageBox.Show($"通道 {packet.Number} 错误: {errorMessage}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
    
    /// <summary>
    /// 处理握手响应包
    /// </summary>
    private void HandleHandshakeResponse(ProtocolPacket packet)
    {
        if (channelControls == null) return;

        _handshakeResponseTcs?.TrySetResult(true);
        _handshakeCompleted = true;  // 收到握手响应即标记握手完成
        
        if (packet.Number == 0)
        {
            foreach (var channel in channelControls)
            {
                channel.UpdateStatus(ChannelStatus.Waiting, 0);
            }
            _logger?.Info("握手成功 - 全部通道就绪");
            return;
        }

        int channelIndex = packet.Number - 1;
        if (channelIndex < 0 || channelIndex >= channelControls.Length)
            return;

        channelControls[channelIndex].UpdateStatus(ChannelStatus.Waiting, 0);
        _logger?.Info($"通道 {packet.Number} 握手成功");
    }
    
    /// <summary>
    /// 处理烧录确认包
    /// </summary>
    private void HandleProgramConfirm(ProtocolPacket packet, ChannelControl channel)
    {
        channel.UpdateStatus(ChannelStatus.Programming, 0);
        Console.WriteLine($"通道 {packet.Number} 开始烧录");
    }
    
    /// <summary>
    /// 处理固件接收完成包
    /// </summary>
    private void HandleFirmwareComplete(ProtocolPacket packet, ChannelControl channel)
    {
        channel.UpdateStatus(ChannelStatus.Waiting, 100);
        Console.WriteLine($"通道 {packet.Number} 固件接收完成");
    }
    
    /// <summary>
    /// 处理烧写完成包
    /// </summary>
    private void HandleProgramComplete(ProtocolPacket packet, ChannelControl channel)
    {
        channel.UpdateStatus(ChannelStatus.Success, 100);
        TrySaveBurnRecord(channel.ChannelNumber, (byte)ProgramStatus.ProgramComplete, "Success", GetStatusText(ProgramStatus.ProgramComplete));
        TryHandleBatchCompletionAfterFinalStatus();
        Console.WriteLine($"通道 {packet.Number} 烧录完成");
    }
    
    /// <summary>
    /// 处理擦除确认包
    /// </summary>
    private void HandleEraseConfirm(ProtocolPacket packet, ChannelControl channel)
    {
        channel.UpdateStatus(ChannelStatus.Erasing, 0);
        Console.WriteLine($"通道 {packet.Number} 开始擦除");
    }
    
    private void BtnBatchScanStart_Click(object? sender, EventArgs e)
    {
        if (serialComm == null || !serialComm.IsOpen)
        {
            MessageBox.Show("请先连接串口！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (!_handshakeCompleted)
        {
            MessageBox.Show("设备未完成握手，请先等待握手完成或重新连接！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        int totalChannels = channelControls?.Length ?? 0;
        if (totalChannels == 0) return;

        using (var batchForm = new BatchScanForm(totalChannels, code => GetQrCodeValidationError(code)))
        {
            if (batchForm.ShowDialog() == DialogResult.OK)
            {
                // 将扫码结果同步到主界面
                foreach (var kvp in batchForm.ScannedData)
                {
                    int channel = kvp.Key;
                    string code = kvp.Value;
                    if (code != "[已跳过]")
                    {
                        ProcessScannedQrCodeForChannel(channel, code);
                    }
                }

                // 操作员确认放板并压下治具后，触发一键启动全部
                _logger?.Info("批量扫码完成，操作员确认后触发启动指令");
                BtnStartAll_Click(this, EventArgs.Empty);
            }
            else
            {
                _logger?.Warning("用户取消了批量扫码，不自动启动烧录。");
            }
        }
    }

    private void BtnStartAll_Click(object? sender, EventArgs e)
{
    if (serialComm == null || !serialComm.IsOpen)
    {
        MessageBox.Show("请先连接串口！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        _logger?.Error("批量启动失败: 串口未连接");
        return;
    }
    
    // 检查是否已完成握手
    if (!_handshakeCompleted)
    {
        MessageBox.Show("设备未完成握手，请先等待握手完成或重新连接！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        _logger?.Error("批量启动失败: 设备未握手");
        return;
    }
    
    _logger?.Info($"开始批量启动 {channelControls.Length} 个通道");
    _currentBatchId = BuildBatchId();

    ushort channelMask = BuildChannelMask(channelControls.Length);
    if (channelMask == 0)
    {
        MessageBox.Show("当前没有可启动的通道！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        _logger?.Warning("批量启动被取消: 当前没有启用通道");
        return;
    }

    foreach (var channel in channelControls)
    {
        channel.UpdateStatus(ChannelStatus.Waiting, 0);
    }

    bool success = IsEightChannelMode()
        ? serialComm.SendStartProgram(channelMask)
        : (IsMultiChannelMode()
            ? serialComm.SendStartProgramBroadcast(channelMask, 0)
            : serialComm.SendStartProgram(0));

    if (success)
    {
        BeginTraceForAllChannels(true);
        RequestCurrentFirmwareNameForAllChannels();
        _logger?.Info($"批量启动命令发送成功: mask=0x{channelMask:X4}, 通道数={channelControls.Length}");
        _logger?.Info($"本次批量任务编号: {_currentBatchId}");
        MessageBox.Show($"已发送批量启动烧录命令到 {channelControls.Length} 个通道！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);

        for (ushort i = 1; i <= channelControls.Length; i++)
        {
            StopProgressPolling(i);
        }
    }
    else
    {
        _currentBatchId = null;
        _logger?.Error("批量启动命令发送失败");
        MessageBox.Show("批量启动命令发送失败，请检查串口连接！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
    
    private void BtnStopAll_Click(object? sender, EventArgs e)
    {
        // 停止所有通道（协议中没有明确的停止指令，这里只重置UI状态）
        foreach (var channel in channelControls)
        {
            channel.Reset();
        }

        _traceContexts.Clear();
        _currentBatchId = null;
        MessageBox.Show("已停止所有通道！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    
    private void BtnResetAll_Click(object? sender, EventArgs e)
    {
        foreach (var channel in channelControls)
        {
            channel.Reset();
        }

        _traceContexts.Clear();
        _currentBatchId = null;
    }
    
    private void BtnApplyConfig_Click(object? sender, EventArgs e)
    {
        if (cboChannelCount.SelectedItem is int count)
        {
            config.EnabledChannels = count;
            CreateChannels(count);
            MessageBox.Show($"已应用配置：{count}个通道", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    
    private void BtnSaveConfig_Click(object? sender, EventArgs e)
    {
        if (cboChannelCount.SelectedItem is int count)
        {
            config.EnabledChannels = count;
            config.DefaultPort = cboPort.SelectedItem?.ToString();
            if (int.TryParse(cboBaudRate.SelectedItem?.ToString(), out int baud))
                config.DefaultBaudRate = baud;
            config.AutoOpenNextBatchScanAfterComplete = _chkAutoNextBatchScan?.Checked == true;
            config.Save();
            MessageBox.Show("配置已保存！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    
    private async void BtnReadDeviceInfo_Click(object? sender, EventArgs e)
    {
        if (serialComm == null || !serialComm.IsOpen)
        {
            MessageBox.Show("请先连接串口！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        // 检查是否已完成握手
        if (!_handshakeCompleted)
        {
            MessageBox.Show("设备未完成握手，请先等待握手完成或重新连接！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _logger?.Info("正在读取设备信息...");
        
        // 使用异步方式发送指令并等待响应
        bool responseReceived = false;
        EventHandler<PacketReceivedEventArgs>? handler = null;
        
        handler = (s, e) =>
        {
            if (e.Packet.Header == FrameHeader.DeviceInfoResponse)
            {
                responseReceived = true;
                serialComm.PacketReceived -= handler;
            }
        };
        
        serialComm.PacketReceived += handler;
        
        // 发送读取设备信息指令到所有通道
        for (ushort i = 1; i <= channelControls.Length; i++)
        {
            serialComm.SendReadDeviceInfo(i);
            await Task.Delay(50);
        }
        
        // 等待响应（最多等待3秒）
        int timeoutMs = 3000;
        int waitInterval = 100;
        int waitedMs = 0;
        
        while (!responseReceived && waitedMs < timeoutMs)
        {
            await Task.Delay(waitInterval);
            waitedMs += waitInterval;
        }
        
        serialComm.PacketReceived -= handler;
        
        if (!responseReceived)
        {
            _logger?.Error("读取设备信息超时，设备未响应");
            MessageBox.Show("读取设备信息超时，设备未响应！\n请检查：\n1. 设备是否上电\n2. 串口线是否连接正确\n3. 串口参数是否正确", 
                          "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    
    private void BtnLoopTest_Click(object? sender, EventArgs e)
    {
        if (serialComm == null || !serialComm.IsOpen)
        {
            MessageBox.Show("请先连接串口！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _logger?.Info("开始环路测试...");
        lblLoopTestStatus.Text = "测试中...";
        lblLoopTestStatus.ForeColor = Color.Orange;

        // 执行环路测试
        bool allPassed = RunLoopTests();

        if (allPassed)
        {
            _logger?.Info("环路测试全部通过！");
            lblLoopTestStatus.Text = "测试通过";
            lblLoopTestStatus.ForeColor = Color.Green;
            MessageBox.Show("环路测试全部通过！", "测试结果", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        else
        {
            _logger?.Error("环路测试失败！");
            lblLoopTestStatus.Text = "测试失败";
            lblLoopTestStatus.ForeColor = Color.Red;
            MessageBox.Show("环路测试失败，请检查日志！", "测试结果", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private bool RunLoopTests()
    {
        bool allPassed = true;

        // 测试1: 帧结构验证
        allPassed &= TestFrameStructure();

        // 测试2: CRC校验验证
        allPassed &= TestCrcValidation();

        // 测试3: 指令帧头验证
        allPassed &= TestFrameHeaders();

        // 测试4: 分包逻辑验证
        allPassed &= TestPacketSplitting();

        return allPassed;
    }

    private bool TestFrameStructure()
    {
        _logger?.Info("测试1: 帧结构验证");
        
        // 创建一个测试数据包
        byte[] testData = { 0x01, 0x02, 0x03, 0x04 };

        // 打包
        byte[] packed = ProtocolPacker.Pack(FrameHeader.HandshakeRequest, 1, testData);

        // 验证帧结构: 1字节帧头 + 1字节长度 + 2字节编号 + 数据 + 2字节CRC
        int expectedLength = 1 + 1 + 2 + testData.Length + 2;
        
        if (packed.Length != expectedLength)
        {
            _logger?.Error($"帧结构错误: 期望长度 {expectedLength}, 实际长度 {packed.Length}");
            return false;
        }

        // 验证帧头位置
        if (packed[0] != (byte)FrameHeader.HandshakeRequest)
        {
            _logger?.Error($"帧头位置错误: 期望 0x{FrameHeader.HandshakeRequest:X2}, 实际 0x{packed[0]:X2}");
            return false;
        }

        // 验证长度字段
        byte expectedLengthField = (byte)packed.Length; // 包含CRC的长度
        if (packed[1] != expectedLengthField)
        {
            _logger?.Error($"长度字段错误: 期望 0x{expectedLengthField:X2}, 实际 0x{packed[1]:X2}");
            return false;
        }

        _logger?.Info("帧结构验证通过");
        return true;
    }

    private bool TestCrcValidation()
    {
        _logger?.Info("测试2: CRC校验验证");

        // 创建测试数据包
        byte[] testData = { 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF };

        // 打包
        byte[] packed = ProtocolPacker.Pack(FrameHeader.StartProgram, 1, testData);

        // 手动计算CRC验证
        byte[] dataWithoutCrc = new byte[packed.Length - 2];
        Array.Copy(packed, dataWithoutCrc, dataWithoutCrc.Length);
        
        ushort expectedCrc = Crc16Modbus.Calculate(dataWithoutCrc);
        ushort actualCrc = BitConverter.ToUInt16(packed, packed.Length - 2);

        if (expectedCrc != actualCrc)
        {
            _logger?.Error($"CRC校验失败: 期望 0x{expectedCrc:X4}, 实际 0x{actualCrc:X4}");
            return false;
        }

        _logger?.Info("CRC校验验证通过");
        return true;
    }

    private bool TestFrameHeaders()
    {
        _logger?.Info("测试3: 指令帧头验证");

        FrameHeader[] headersToTest = {
            FrameHeader.HandshakeRequest,
            FrameHeader.StartProgram,
            FrameHeader.ReadDeviceInfo,
            FrameHeader.QueryProgress
        };

        foreach (var header in headersToTest)
        {
            byte[] packed = ProtocolPacker.Pack(header, 1, new byte[0]);

            if (packed[0] != (byte)header)
            {
                _logger?.Error($"帧头 {header} 打包错误: 期望 0x{(byte)header:X2}, 实际 0x{packed[0]:X2}");
                return false;
            }
        }

        _logger?.Info("指令帧头验证通过");
        return true;
    }

    private bool TestPacketSplitting()
    {
        _logger?.Info("测试4: 分包逻辑验证");

        // 创建一个刚好64字节的数据（64 = 1+1+2+58+2）
        byte[] maxData = new byte[58];
        for (int i = 0; i < maxData.Length; i++)
        {
            maxData[i] = (byte)i;
        }

        try
        {
            // 测试最大包长
            byte[] packed = ProtocolPacker.Pack(FrameHeader.FirmwareData, 1, maxData);
            
            // 验证总长度
            int expectedLength = 1 + 1 + 2 + maxData.Length + 2;
            if (packed.Length != expectedLength)
            {
                _logger?.Error($"最大数据包长度错误: 期望 {expectedLength}, 实际 {packed.Length}");
                return false;
            }

            _logger?.Info("最大包长测试通过");
        }
        catch (ArgumentException ex)
        {
            _logger?.Error($"最大包长测试失败: {ex.Message}");
            return false;
        }

        // 测试超过最大长度时是否抛出异常
        byte[] largeData = new byte[60]; // 超过最大限制
        try
        {
            ProtocolPacker.Pack(FrameHeader.FirmwareData, 1, largeData);
            _logger?.Error("超长数据包应该抛出异常但没有");
            return false;
        }
        catch (ArgumentException)
        {
            _logger?.Info("超长数据包正确地抛出了异常");
        }

        _logger?.Info("分包逻辑验证通过");
        return true;
    }
    
    private void Log(string message)
    {
        _logger?.Info(message);
    }

    private void BtnTraceQuery_Click(object? sender, EventArgs e)
    {
        if (_traceabilityRepository == null)
        {
            MessageBox.Show("追溯数据库未初始化，无法查询。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        using var traceQueryForm = new TraceQueryForm(_traceabilityRepository, _logger);
        traceQueryForm.ShowDialog(this);
    }
    
    private void LogToUi(string message)
    {
        if (txtLog.InvokeRequired)
        {
            txtLog.Invoke((MethodInvoker)(() => LogToUi(message)));
            return;
        }
        
        txtLog.AppendText(message);
        txtLog.ScrollToCaret();
    }
    
    private void OnRawDataReceived(object? sender, DataReceivedEventArgs e)
    {
        _logger?.Debug($"串口数据: {e.Data}");
    }
    
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        CancelHandshakeFlow();
        for (ushort i = 1; i <= _progressPollingCts.Length; i++)
        {
            StopProgressPolling(i);
        }

        serialComm?.ClosePort();
        base.OnFormClosing(e);
    }
}
