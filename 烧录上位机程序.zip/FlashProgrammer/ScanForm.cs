using System;
using System.Drawing;
using System.Windows.Forms;

namespace FlashProgrammer;

public partial class ScanForm : Form
{
    public string QrCodeContent { get; private set; } = string.Empty;

    private TextBox txtManualInput;
    private Label lblStatus;
    private Button btnConfirm;
    private Button btnCancel;
    private System.Windows.Forms.Timer _autoSubmitTimer;
    private bool _isSubmitting;

    public ScanForm()
    {
        InitializeComponent();
        FormDisplayHelper.FitToWorkingArea(this, new Size(520, 320), new Size(460, 280));
    }

    private void InitializeComponent()
    {
        this.Text = "扫码确认";
        this.Size = new Size(520, 320);
        this.StartPosition = FormStartPosition.CenterParent;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.KeyPreview = true;

        Label lblHint = new Label
        {
            Text = "请扫描或输入二维码内容，内容输入后1秒将自动完成录入。",
            Location = new Point(20, 15),
            Size = new Size(460, 40),
            Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold)
        };

        _autoSubmitTimer = new System.Windows.Forms.Timer { Interval = 500 };
        _autoSubmitTimer.Tick += (s, e) => {
            _autoSubmitTimer.Stop();
            string code = txtManualInput.Text.Trim();
            if (!string.IsNullOrWhiteSpace(code)) {
                SubmitCode(code);
            }
        };

        txtManualInput = new TextBox
        {
            Location = new Point(20, 65),
            Size = new Size(460, 35),
            Font = new Font("Microsoft YaHei UI", 12F),
            BorderStyle = BorderStyle.FixedSingle,
            TabStop = true
        };

        lblStatus = new Label
        {
            Text = "等待录入...",
            Location = new Point(20, 115),
            Size = new Size(460, 60),
            Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold),
            ForeColor = Color.Blue,
            TextAlign = ContentAlignment.MiddleCenter,
            BorderStyle = BorderStyle.FixedSingle
        };

        btnConfirm = new Button
        {
            Text = "确定",
            Location = new Point(260, 200),
            Size = new Size(100, 40),
            BackColor = Color.FromArgb(46, 204, 113),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold)
        };
        btnConfirm.FlatAppearance.BorderSize = 0;
        btnConfirm.Click += (s, e) => SubmitCurrentInput();

        btnCancel = new Button
        {
            Text = "取消",
            Location = new Point(380, 200),
            Size = new Size(100, 40),
            BackColor = Color.Gray,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Microsoft YaHei UI", 10F)
        };
        btnCancel.FlatAppearance.BorderSize = 0;
        btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

        this.Controls.Add(lblHint);
        this.Controls.Add(txtManualInput);
        this.Controls.Add(lblStatus);
        this.Controls.Add(btnConfirm);
        this.Controls.Add(btnCancel);

        this.Load += ScanForm_Load;
        this.Shown += ScanForm_Shown;
        this.Activated += ScanForm_Activated;
        txtManualInput.KeyDown += TxtManualInput_KeyDown;
        txtManualInput.TextChanged += (s, e) => {
            if (_isSubmitting)
            {
                return;
            }
            _autoSubmitTimer.Stop();
            if (!string.IsNullOrWhiteSpace(txtManualInput.Text)) {
                lblStatus.Text = "已识别内容，0.5 秒后自动录入...";
                lblStatus.ForeColor = Color.DarkOrange;
                _autoSubmitTimer.Start();
            }
            else
            {
                lblStatus.Text = "等待录入...";
                lblStatus.ForeColor = Color.Blue;
            }
        };
    }

    private void ScanForm_Load(object? sender, EventArgs e)
    {
        PrepareForScanning();
    }

    private void ScanForm_Shown(object? sender, EventArgs e)
    {
        PrepareForScanning();
    }

    private void ScanForm_Activated(object? sender, EventArgs e)
    {
        PrepareForScanning();
    }

    private void PrepareForScanning()
    {
        _autoSubmitTimer.Stop();
        _isSubmitting = false;
        if (!string.IsNullOrWhiteSpace(txtManualInput.Text))
        {
            return;
        }
        txtManualInput.Focus();
        txtManualInput.SelectAll();
    }

    private void TxtManualInput_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode != Keys.Enter)
        {
            return;
        }

        e.SuppressKeyPress = true;
        SubmitCurrentInput();
    }

    private void SubmitCode(string code)
    {
        code = code.Trim();
        if (string.IsNullOrWhiteSpace(code))
            return;

        _isSubmitting = true;
        lblStatus.Text = "扫码成功";
        lblStatus.ForeColor = Color.Green;

        if (this.InvokeRequired)
        {
            this.BeginInvoke(new Action(() => 
            {
                this.QrCodeContent = code;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }));
        }
        else
        {
            this.QrCodeContent = code;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }

    private void SubmitCurrentInput()
    {
        _autoSubmitTimer.Stop();
        if (_isSubmitting)
        {
            return;
        }

        string code = txtManualInput.Text.Trim();
        if (string.IsNullOrWhiteSpace(code))
        {
            PrepareForScanning();
            return;
        }

        SubmitCode(code);
    }
}
