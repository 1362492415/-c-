namespace FlashProgrammer;

public class ProtocolParser
{
    public event EventHandler<ChannelUpdateEventArgs>? ChannelUpdated;

    public void ParseAndUpdate(string rawData, ChannelControl[] channelControls)
    {
        string[] lines = rawData.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        
        foreach (string line in lines)
        {
            ParseLine(line, channelControls);
        }
    }

    public void ParseData(string rawData)
    {
        string[] lines = rawData.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        
        foreach (string line in lines)
        {
            ParseLine(line);
        }
    }

    private void ParseLine(string line, ChannelControl[]? channelControls = null)
    {
        try
        {
            if (!line.StartsWith("[") || !line.Contains("]"))
                return;

            int channelEndIndex = line.IndexOf(']');
            if (!int.TryParse(line.Substring(1, channelEndIndex - 1), out int channelNumber))
                return;

            if (channelNumber < 1 || channelNumber > 12)
                return;

            string remaining = line.Substring(channelEndIndex + 1);
            
            if (remaining.StartsWith("STATUS:"))
            {
                string statusStr = remaining.Substring(7);
                ParseStatus(channelNumber, statusStr, channelControls);
            }
            else if (remaining.StartsWith("PROGRESS:"))
            {
                if (int.TryParse(remaining.Substring(9), out int progress))
                {
                    ParseProgress(channelNumber, progress, channelControls);
                }
            }
            else if (remaining.StartsWith("RESULT:"))
            {
                string result = remaining.Substring(7);
                ParseResult(channelNumber, result, channelControls);
            }
            else if (remaining.StartsWith("QRCODE:"))
            {
                string qrCodeData = remaining.Substring(7);
                ParseQRCode(channelNumber, qrCodeData, channelControls);
            }
        }
        catch { }
    }

    private void ParseStatus(int channelNumber, string statusStr, ChannelControl[]? channelControls)
    {
        ChannelStatus status = statusStr switch
        {
            "ERASING" or "ERASE" => ChannelStatus.Erasing,
            "PROGRAMMING" or "PROG" => ChannelStatus.Programming,
            "SUCCESS" or "OK" => ChannelStatus.Success,
            "FAILED" or "ERROR" => ChannelStatus.Failed,
            _ => ChannelStatus.Waiting
        };

        if (channelControls != null)
        {
            int index = channelNumber - 1;
            if (index >= 0 && index < channelControls.Length)
            {
                channelControls[index].UpdateStatus(status);
            }
        }
        else
        {
            ChannelUpdated?.Invoke(this, new ChannelUpdateEventArgs(channelNumber, status, null, null));
        }
    }

    private void ParseProgress(int channelNumber, int progress, ChannelControl[]? channelControls)
    {
        if (channelControls != null)
        {
            int index = channelNumber - 1;
            if (index >= 0 && index < channelControls.Length)
            {
                channelControls[index].UpdateProgress(progress);
            }
        }
        else
        {
            ChannelUpdated?.Invoke(this, new ChannelUpdateEventArgs(channelNumber, null, progress, null));
        }
    }

    private void ParseResult(int channelNumber, string result, ChannelControl[]? channelControls)
    {
        ChannelStatus status = result switch
        {
            "SUCCESS" or "OK" => ChannelStatus.Success,
            "FAILED" or "ERROR" => ChannelStatus.Failed,
            _ => ChannelStatus.Waiting
        };

        if (channelControls != null)
        {
            int index = channelNumber - 1;
            if (index >= 0 && index < channelControls.Length)
            {
                channelControls[index].UpdateStatus(status, status == ChannelStatus.Success ? 100 : 0);
            }
        }
        else
        {
            ChannelUpdated?.Invoke(this, new ChannelUpdateEventArgs(channelNumber, status, status == ChannelStatus.Success ? 100 : 0, null));
        }
    }

    private void ParseQRCode(int channelNumber, string qrCodeData, ChannelControl[]? channelControls)
    {
        if (channelControls != null)
        {
            int index = channelNumber - 1;
            if (index >= 0 && index < channelControls.Length)
            {
                channelControls[index].UpdateQRCode(qrCodeData);
            }
        }
        else
        {
            ChannelUpdated?.Invoke(this, new ChannelUpdateEventArgs(channelNumber, null, null, qrCodeData));
        }
    }

    public string BuildCommand(int channelNumber, string commandType, params string[] parameters)
    {
        string paramStr = string.Join(",", parameters);
        return $"[{channelNumber:D2}]{commandType}{paramStr}";
    }
}

public class ChannelUpdateEventArgs : EventArgs
{
    public int ChannelNumber { get; }
    public ChannelStatus? Status { get; }
    public int? Progress { get; }
    public string? QRCodeData { get; }

    public ChannelUpdateEventArgs(int channelNumber, ChannelStatus? status, int? progress, string? qrCodeData)
    {
        ChannelNumber = channelNumber;
        Status = status;
        Progress = progress;
        QRCodeData = qrCodeData;
    }
}
