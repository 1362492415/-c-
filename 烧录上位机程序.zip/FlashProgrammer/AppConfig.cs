using System;
using System.IO;
using System.Text.Json;

namespace FlashProgrammer;

public class AppConfig
{
    public int EnabledChannels { get; set; } = 12;
    public int GridColumns { get; set; } = 4;
    public bool ShowQrCode { get; set; } = true;
    public string? DefaultPort { get; set; }
    public int DefaultBaudRate { get; set; } = 115200;
    public string TraceabilityConnectionString { get; set; } = string.Empty;
    public string? DefaultFirmwareName { get; set; }
    public bool AutoOpenNextBatchScanAfterComplete { get; set; } = false;

    private static readonly string ConfigPath = Path.Combine(
        AppDomain.CurrentDomain.BaseDirectory,
        "appsettings.json");

    public static AppConfig Load()
    {
        if (File.Exists(ConfigPath))
        {
            try
            {
                string json = File.ReadAllText(ConfigPath);
                var config = JsonSerializer.Deserialize<AppConfig>(json);
                return config ?? new AppConfig();
            }
            catch
            {
                return new AppConfig();
            }
        }
        return new AppConfig();
    }

    public void Save()
    {
        try
        {
            string json = JsonSerializer.Serialize(this, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            File.WriteAllText(ConfigPath, json);
        }
        catch
        {
            // 保存失败不报错
        }
    }
}
