using System;
using System.Collections.Generic;
using System.IO.Ports;

namespace FlashProgrammer;

/// <summary>
/// 串口通信器
/// 实现基于协议规范的串口数据收发功能
/// </summary>
public class SerialCommunicator
{
    private SerialPort? _serialPort;
    private readonly object _lockObj = new object();
    
    // 用于缓存未处理完的数据（多包拼接）
    private byte[] _remainingData = Array.Empty<byte>();
    
    // 超时时间（毫秒）
    private const int TimeoutMs = 5000;
    
    // 事件：接收到完整数据包
    public event EventHandler<PacketReceivedEventArgs>? PacketReceived;
    
    // 事件：接收到原始数据（用于调试）
    public event EventHandler<DataReceivedEventArgs>? RawDataReceived;
    
    // 属性：串口是否打开
    public bool IsOpen => _serialPort?.IsOpen ?? false;
    
    /// <summary>
    /// 获取可用串口列表
    /// </summary>
    public string[] GetAvailablePorts()
    {
        return SerialPort.GetPortNames();
    }
    
    /// <summary>
    /// 打开串口
    /// </summary>
    /// <param name="portName">串口名称</param>
    /// <param name="baudRate">波特率，默认115200</param>
    /// <returns>是否成功打开</returns>
    public bool OpenPort(string portName, int baudRate = 115200)
    {
        try
        {
            // 如果串口已打开，先关闭
            if (_serialPort?.IsOpen ?? false)
            {
                _serialPort.Close();
            }
            
            // 创建新的串口对象
            _serialPort = new SerialPort(portName, baudRate, Parity.None, 8, StopBits.One)
            {
                ReadTimeout = TimeoutMs,
                WriteTimeout = TimeoutMs,
                DtrEnable = true,
                RtsEnable = true
            };
            
            // 订阅数据接收事件
            _serialPort.DataReceived += SerialPort_DataReceived;
            
            // 打开串口
            _serialPort.Open();
            
            // 重置剩余数据缓存
            _remainingData = Array.Empty<byte>();
            
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"打开串口失败: {ex.Message}");
            return false;
        }
    }
    
    /// <summary>
    /// 关闭串口
    /// </summary>
    public void ClosePort()
    {
        try
        {
            if (_serialPort?.IsOpen ?? false)
            {
                _serialPort.DataReceived -= SerialPort_DataReceived;
                _serialPort.Close();
            }
            _remainingData = Array.Empty<byte>();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"关闭串口失败: {ex.Message}");
        }
    }
    
    /// <summary>
    /// 串口数据接收事件处理
    /// </summary>
    private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
    {
        try
        {
            SerialPort sp = (SerialPort)sender;
            
            // 读取所有可用字节
            int bytesToRead = sp.BytesToRead;
            byte[] buffer = new byte[bytesToRead];
            int bytesRead = sp.Read(buffer, 0, bytesToRead);
            
            if (bytesRead > 0)
            {
                // 触发原始数据事件（用于调试）
                RawDataReceived?.Invoke(this, new DataReceivedEventArgs(BitConverter.ToString(buffer, 0, bytesRead)));
                
                // 解析数据包
                ParseReceivedData(buffer, bytesRead);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"数据接收处理失败: {ex.Message}");
        }
    }
    
    /// <summary>
    /// 解析接收到的数据，提取完整数据包
    /// </summary>
    private void ParseReceivedData(byte[] data, int length)
    {
        // 创建有效数据数组
        byte[] validData = new byte[length];
        Buffer.BlockCopy(data, 0, validData, 0, length);
        
        // 使用协议解包器解析
        List<ProtocolPacket> packets = ProtocolUnpacker.Unpack(validData, ref _remainingData);
        
        // 触发数据包接收事件
        foreach (var packet in packets)
        {
            PacketReceived?.Invoke(this, new PacketReceivedEventArgs(packet));
        }
    }
    
    /// <summary>
    /// 清理串口接收缓冲区
    /// </summary>
    public void ClearReceiveBuffer()
    {
        try
        {
            if (_serialPort?.IsOpen ?? false)
            {
                _serialPort.DiscardInBuffer();
                _remainingData = Array.Empty<byte>();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"清理接收缓冲区失败: {ex.Message}");
        }
    }
    
    /// <summary>
    /// 发送原始字节数据（发送前先清理接收缓冲区）
    /// </summary>
    public bool SendRawData(byte[] data)
    {
        try
        {
            if (!(_serialPort?.IsOpen ?? false))
                return false;
            
            lock (_lockObj)
            {
                _serialPort.Write(data, 0, data.Length);
            }
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"发送数据失败: {ex.Message}");
            return false;
        }
    }
    
    /// <summary>
    /// 发送协议数据包
    /// </summary>
    public bool SendPacket(ProtocolPacket packet)
    {
        byte[] data = ProtocolPacker.Pack(packet.Header, packet.Number, packet.Data);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送握手指令
    /// </summary>
    public bool SendHandshake(ushort channel = 0)
    {
        byte[] data = ProtocolCommands.Handshake(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送开始烧录指令（单通道）
    /// </summary>
    public bool SendStartProgram(ushort channel)
    {
        byte[] data = ProtocolCommands.StartProgram(channel);
        return SendRawData(data);
    }

    /// <summary>
    /// 发送开始烧录指令（多通道广播）
    /// 例如 12 路全开：channelMask=0x0FFF，param=0x0000 => A8 08 FF 0F 00 00 xx xx
    /// </summary>
    public bool SendStartProgramBroadcast(ushort channelMask, ushort param = 0)
    {
        byte[] data = ProtocolCommands.StartProgramBroadcast(channelMask, param);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送查询进度指令
    /// </summary>
    public bool SendQueryProgress(ushort channel)
    {
        byte[] data = ProtocolCommands.QueryProgress(channel);
        return SendRawData(data);
    }

    /// <summary>
    /// 发送查询当前烧录文件名指令
    /// </summary>
    public bool SendQueryFileName(ushort channel)
    {
        byte[] data = ProtocolCommands.QueryFileName(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送执行全部指令（擦除+烧录+校验）
    /// </summary>
    public bool SendExecuteAll(ushort channel)
    {
        byte[] data = ProtocolCommands.ExecuteAll(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送读取设备ID指令
    /// </summary>
    public bool SendReadDeviceId(ushort channel)
    {
        byte[] data = ProtocolCommands.ReadDeviceId(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送读取设备信息指令
    /// </summary>
    public bool SendReadDeviceInfo(ushort channel)
    {
        byte[] data = ProtocolCommands.ReadDeviceInfo(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送选择文件指令
    /// </summary>
    public bool SendSelectFile(ushort channel, ushort fileIndex)
    {
        byte[] data = ProtocolCommands.SelectFile(channel, fileIndex);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送读取全部文件列表指令
    /// </summary>
    public bool SendReadAllFiles(ushort channel)
    {
        byte[] data = ProtocolCommands.ReadAllFiles(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送删除全部文件指令
    /// </summary>
    public bool SendDeleteAllFiles(ushort channel)
    {
        byte[] data = ProtocolCommands.DeleteAllFiles(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送单独擦除指令
    /// </summary>
    public bool SendErase(ushort channel)
    {
        byte[] data = ProtocolCommands.Erase(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送单独编程指令
    /// </summary>
    public bool SendProgram(ushort channel)
    {
        byte[] data = ProtocolCommands.Program(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送单独校验指令
    /// </summary>
    public bool SendVerify(ushort channel)
    {
        byte[] data = ProtocolCommands.Verify(channel);
        return SendRawData(data);
    }
    
    /// <summary>
    /// 发送批量指令到所有通道
    /// </summary>
    public bool SendBatchCommand(Func<ushort, bool> commandFunc, int channelCount = 12)
    {
        bool allSuccess = true;
        for (ushort i = 1; i <= channelCount; i++)
        {
            if (!commandFunc(i))
            {
                allSuccess = false;
            }
        }
        return allSuccess;
    }
    
    /// <summary>
    /// 发送批量握手指令
    /// </summary>
    public bool SendBatchHandshake(int channelCount = 12)
    {
        return SendBatchCommand(SendHandshake, channelCount);
    }
    
    /// <summary>
    /// 发送批量开始烧录指令
    /// </summary>
    public bool SendBatchStartProgram(int channelCount = 12)
    {
        return SendBatchCommand(SendStartProgram, channelCount);
    }
    
    /// <summary>
    /// 发送批量查询进度指令
    /// </summary>
    public bool SendBatchQueryProgress(int channelCount = 12)
    {
        return SendBatchCommand(SendQueryProgress, channelCount);
    }

    /// <summary>
    /// 发送批量查询当前烧录文件名指令
    /// </summary>
    public bool SendBatchQueryFileName(int channelCount = 12)
    {
        return SendBatchCommand(SendQueryFileName, channelCount);
    }
    
    /// <summary>
    /// 发送批量执行全部指令（擦除+烧录+校验）
    /// </summary>
    public bool SendBatchExecuteAll(int channelCount = 12)
    {
        return SendBatchCommand(SendExecuteAll, channelCount);
    }
}

/// <summary>
/// 原始数据接收事件参数
/// </summary>
public class DataReceivedEventArgs : EventArgs
{
    public string Data { get; }
    
    public DataReceivedEventArgs(string data)
    {
        Data = data;
    }
}

/// <summary>
/// 协议数据包接收事件参数
/// </summary>
public class PacketReceivedEventArgs : EventArgs
{
    public ProtocolPacket Packet { get; }
    
    public PacketReceivedEventArgs(ProtocolPacket packet)
    {
        Packet = packet;
    }
}
