namespace FlashProgrammer;

public partial class ChannelControl : UserControl
{
    private ChannelData _channelData;

    public ChannelControl()
    {
        InitializeComponent();
    }

    public void Initialize(int channelNumber)
    {
        _channelData = new ChannelData { ChannelNumber = channelNumber, Status = ChannelStatus.Waiting, Progress = 0 };
        lblChannel.Text = $"通道 {channelNumber}";
        UpdateDisplay();
    }

    /// <summary>
    /// 获取当前通道的二维码数据（用于判断是否已有二维码）
    /// </summary>
    public string? QRCodeData => _channelData.QRCodeData;

    public void UpdateStatus(ChannelStatus status, int progress = 0)
    {
        _channelData.Status = status;
        _channelData.Progress = progress;
        UpdateDisplay();
    }

    public void UpdateProgress(int progress)
    {
        _channelData.Progress = progress;
        progressBar.Value = progress;
        lblProgress.Text = $"{progress}%";
    }

    public void UpdateQRCode(string qrCodeBase64)
    {
        try
        {
            _channelData.QRCodeData = qrCodeBase64;
            if (!string.IsNullOrEmpty(qrCodeBase64))
            {
                byte[] imageBytes = Convert.FromBase64String(qrCodeBase64);
                using (var ms = new System.IO.MemoryStream(imageBytes))
                {
                    _channelData.QRCodeImage = System.Drawing.Image.FromStream(ms);
                }
            }
            else
            {
                _channelData.QRCodeImage = null;
            }
            UpdateQRCodeDisplay();
        }
        catch (Exception)
        {
            _channelData.QRCodeImage = null;
            UpdateQRCodeDisplay();
        }
    }

    public void UpdateQRCodeByText(string text)
    {
        try
        {
            _channelData.QRCodeData = text;
            _channelData.QRCodeImage = QrCodeScanner.GenerateQrCode(text);
            UpdateQRCodeDisplay();
        }
        catch
        {
            _channelData.QRCodeImage = null;
            UpdateQRCodeDisplay();
        }
    }

    public void Reset()
    {
        _channelData.Status = ChannelStatus.Waiting;
        _channelData.Progress = 0;
        _channelData.QRCodeData = null;
        _channelData.QRCodeImage = null;
        UpdateDisplay();
        UpdateQRCodeDisplay();
    }

    private void UpdateDisplay()
    {
        lblStatus.Text = _channelData.StatusText;
        progressBar.Value = _channelData.Progress;
        lblProgress.Text = $"{_channelData.Progress}%";

        if (_channelData.Status == ChannelStatus.Waiting)
        {
            lblStatus.ForeColor = Color.FromArgb(100, 100, 100);
            progressBar.ForeColor = Color.FromArgb(150, 150, 150);
            this.BackColor = Color.FromArgb(245, 245, 245);
        }
        else if (_channelData.Status == ChannelStatus.Erasing)
        {
            lblStatus.ForeColor = Color.FromArgb(230, 126, 34);
            progressBar.ForeColor = Color.FromArgb(230, 126, 34);
            this.BackColor = Color.FromArgb(255, 248, 230);
        }
        else if (_channelData.Status == ChannelStatus.Programming)
        {
            lblStatus.ForeColor = Color.FromArgb(41, 128, 185);
            progressBar.ForeColor = Color.FromArgb(41, 128, 185);
            this.BackColor = Color.FromArgb(235, 245, 255);
        }
        else if (_channelData.Status == ChannelStatus.Success)
        {
            lblStatus.ForeColor = Color.FromArgb(39, 174, 96);
            progressBar.ForeColor = Color.FromArgb(39, 174, 96);
            progressBar.Value = 100;
            lblProgress.Text = "100%";
            this.BackColor = Color.FromArgb(230, 255, 230);
        }
        else if (_channelData.Status == ChannelStatus.Failed)
        {
            lblStatus.ForeColor = Color.FromArgb(192, 57, 43);
            progressBar.ForeColor = Color.FromArgb(192, 57, 43);
            this.BackColor = Color.FromArgb(255, 235, 235);
        }
    }

    private void UpdateQRCodeDisplay()
    {
        if (_channelData.QRCodeImage != null)
        {
            pictureBoxQRCode.Image = _channelData.QRCodeImage;
            lblQRCodeHint.Text = "产品二维码";
            lblQRCodeHint.Visible = true;
            lblQRCodeData.Text = _channelData.QRCodeData ?? "";
            lblQRCodeData.Visible = true;
        }
        else
        {
            pictureBoxQRCode.Image = null;
            lblQRCodeHint.Text = "等待二维码";
            lblQRCodeHint.Visible = true;
            lblQRCodeData.Text = "";
            lblQRCodeData.Visible = false;
        }
    }

    public int ChannelNumber => _channelData.ChannelNumber;
    public ChannelStatus CurrentStatus => _channelData.Status;
    public int CurrentProgress => _channelData.Progress;
    
    public event EventHandler? StartButtonClicked;
    public event EventHandler? ScanButtonClicked;
}

partial class ChannelControl
{
        private System.ComponentModel.IContainer components = null;
        private Label lblChannel;
        private Label lblStatus;
        private ProgressBar progressBar;
        private Label lblProgress;
        private PictureBox pictureBoxQRCode;
        private Label lblQRCodeHint;
        private Label lblQRCodeData;
        private Button btnStart;
        private Button btnScanQr;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
        {
            this.lblChannel = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.lblProgress = new System.Windows.Forms.Label();
            this.pictureBoxQRCode = new System.Windows.Forms.PictureBox();
            this.lblQRCodeHint = new System.Windows.Forms.Label();
            this.lblQRCodeData = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnScanQr = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxQRCode)).BeginInit();
            this.SuspendLayout();

        this.lblChannel.AutoSize = true;
        this.lblChannel.Font = new Font("Microsoft YaHei UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point);
        this.lblChannel.Location = new Point(18, 20);
        this.lblChannel.Size = new Size(42, 20);
        this.lblChannel.TabIndex = 0;
        this.lblChannel.Text = "通道 1";
        this.lblChannel.ForeColor = Color.FromArgb(40, 40, 40);

        this.lblStatus.AutoSize = true;
        this.lblStatus.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblStatus.Location = new Point(20, 48);
        this.lblStatus.Size = new Size(42, 15);
        this.lblStatus.TabIndex = 1;
        this.lblStatus.Text = "等待";

        this.progressBar.Location = new Point(20, 76);
        this.progressBar.Size = new Size(300, 18);
        this.progressBar.TabIndex = 2;
        this.progressBar.Maximum = 100;
        this.progressBar.Style = ProgressBarStyle.Continuous;
        this.progressBar.ForeColor = Color.FromArgb(150, 150, 150);
        this.progressBar.BackColor = Color.White;

        this.lblProgress.AutoSize = true;
        this.lblProgress.Font = new Font("Microsoft YaHei UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblProgress.Location = new Point(327, 78);
        this.lblProgress.Size = new Size(25, 15);
        this.lblProgress.TabIndex = 3;
        this.lblProgress.Text = "0%";
        this.lblProgress.ForeColor = Color.FromArgb(80, 80, 80);

        this.pictureBoxQRCode.Location = new Point(20, 112);
        this.pictureBoxQRCode.Size = new Size(120, 120);
        this.pictureBoxQRCode.TabIndex = 4;
        this.pictureBoxQRCode.TabStop = false;
        this.pictureBoxQRCode.BackColor = Color.White;
        this.pictureBoxQRCode.BorderStyle = BorderStyle.FixedSingle;
        this.pictureBoxQRCode.SizeMode = PictureBoxSizeMode.Zoom;

        this.lblQRCodeHint.AutoSize = true;
        this.lblQRCodeHint.Font = new Font("Microsoft YaHei UI", 6.5F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblQRCodeHint.Location = new Point(20, 239);
        this.lblQRCodeHint.Size = new Size(70, 14);
        this.lblQRCodeHint.TabIndex = 5;
        this.lblQRCodeHint.Text = "等待二维码";
        this.lblQRCodeHint.ForeColor = Color.FromArgb(120, 120, 120);

        this.lblQRCodeData.Location = new Point(152, 112);
        this.lblQRCodeData.Size = new Size(200, 142);
        this.lblQRCodeData.TabIndex = 6;
        this.lblQRCodeData.Text = "";
        this.lblQRCodeData.Font = new Font("Microsoft YaHei UI", 6.8F, FontStyle.Regular, GraphicsUnit.Point);
        this.lblQRCodeData.ForeColor = Color.FromArgb(70, 70, 70);
        this.lblQRCodeData.BackColor = Color.White;
        this.lblQRCodeData.BorderStyle = BorderStyle.FixedSingle;
        this.lblQRCodeData.TextAlign = ContentAlignment.TopLeft;
        this.lblQRCodeData.Padding = new Padding(6);
        this.lblQRCodeData.AutoEllipsis = true;
        this.lblQRCodeData.Visible = false;

        this.btnScanQr.Location = new Point(20, 285);
        this.btnScanQr.Size = new Size(160, 30);
        this.btnScanQr.TabIndex = 7;
        this.btnScanQr.Text = "扫码";
        this.btnScanQr.Font = new Font("Microsoft YaHei UI", 8F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnScanQr.UseVisualStyleBackColor = false;
        this.btnScanQr.Click += BtnScanQr_Click;
        this.btnScanQr.BackColor = Color.FromArgb(46, 204, 113);
        this.btnScanQr.ForeColor = Color.White;
        this.btnScanQr.FlatStyle = FlatStyle.Flat;
        this.btnScanQr.FlatAppearance.BorderSize = 0;
        this.btnScanQr.Cursor = Cursors.Hand;

        this.btnStart.Location = new Point(192, 285);
        this.btnStart.Size = new Size(160, 30);
        this.btnStart.TabIndex = 8;
        this.btnStart.Text = "启动烧录";
        this.btnStart.Font = new Font("Microsoft YaHei UI", 8F, FontStyle.Regular, GraphicsUnit.Point);
        this.btnStart.UseVisualStyleBackColor = false;
        this.btnStart.Click += BtnStart_Click;
        this.btnStart.BackColor = Color.FromArgb(41, 128, 185);
        this.btnStart.ForeColor = Color.White;
        this.btnStart.FlatStyle = FlatStyle.Flat;
        this.btnStart.FlatAppearance.BorderSize = 0;
        this.btnStart.Cursor = Cursors.Hand;

        this.AutoScaleDimensions = new SizeF(7F, 17F);
        this.AutoScaleMode = AutoScaleMode.None;
        this.BorderStyle = BorderStyle.FixedSingle;
        this.BackColor = Color.FromArgb(245, 245, 245);
        this.Controls.Add(this.btnScanQr);
        this.Controls.Add(this.btnStart);
        this.Controls.Add(this.lblQRCodeData);
        this.Controls.Add(this.lblQRCodeHint);
        this.Controls.Add(this.pictureBoxQRCode);
        this.Controls.Add(this.lblProgress);
        this.Controls.Add(this.progressBar);
        this.Controls.Add(this.lblStatus);
        this.Controls.Add(this.lblChannel);
        this.Size = new Size(372, 340);
        this.MinimumSize = new Size(372, 340);
        this.MaximumSize = new Size(372, 340);
        ((System.ComponentModel.ISupportInitialize)(this.pictureBoxQRCode)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private void BtnStart_Click(object sender, EventArgs e)
    {
        StartButtonClicked?.Invoke(this, EventArgs.Empty);
    }

    private void BtnScanQr_Click(object sender, EventArgs e)
    {
        ScanButtonClicked?.Invoke(this, EventArgs.Empty);
    }
}
