using System.Drawing;
using System.Windows.Forms;

namespace FlashProgrammer;

internal static class FormDisplayHelper
{
    public static void FitToWorkingArea(Form form, Size preferredClientSize, Size minimumClientSize, int margin = 24)
    {
        Rectangle workingArea = Screen.FromPoint(Cursor.Position).WorkingArea;
        Size minimumWindowSize = ClientSizeToWindowSize(form, minimumClientSize);

        form.MinimumSize = minimumWindowSize;

        int maxClientWidth = Math.Max(minimumClientSize.Width, workingArea.Width - margin);
        int maxClientHeight = Math.Max(minimumClientSize.Height, workingArea.Height - margin);

        int targetClientWidth = Math.Max(minimumClientSize.Width, Math.Min(preferredClientSize.Width, maxClientWidth));
        int targetClientHeight = Math.Max(minimumClientSize.Height, Math.Min(preferredClientSize.Height, maxClientHeight));

        Size targetWindowSize = ClientSizeToWindowSize(form, new Size(targetClientWidth, targetClientHeight));

        form.StartPosition = FormStartPosition.Manual;
        form.Size = targetWindowSize;
        form.Location = new Point(
            workingArea.Left + Math.Max(0, (workingArea.Width - form.Width) / 2),
            workingArea.Top + Math.Max(0, (workingArea.Height - form.Height) / 2));
    }

    private static Size ClientSizeToWindowSize(Form form, Size clientSize)
    {
        int nonClientWidth = form.Width - form.ClientSize.Width;
        int nonClientHeight = form.Height - form.ClientSize.Height;
        return new Size(clientSize.Width + nonClientWidth, clientSize.Height + nonClientHeight);
    }
}
