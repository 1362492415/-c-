namespace FlashProgrammer;

public enum ChannelStatus
{
    Waiting,
    Erasing,
    Programming,
    Success,
    Failed
}

public class ChannelData
{
    public int ChannelNumber { get; set; }
    public ChannelStatus Status { get; set; }
    public int Progress { get; set; }
    public string? QRCodeData { get; set; } // Base64编码的二维码图片数据
    public System.Drawing.Image? QRCodeImage { get; set; } // 加载后的图片对象
    public string StatusText => Status switch
    {
        ChannelStatus.Waiting => "等待",
        ChannelStatus.Erasing => "擦除",
        ChannelStatus.Programming => "烧录",
        ChannelStatus.Success => "成功",
        ChannelStatus.Failed => "失败",
        _ => "未知"
    };
}