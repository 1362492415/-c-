using System;
using System.Drawing;
using System.Windows.Forms;
using ZXing;
using ZXing.Common;
using AForge.Video;
using AForge.Video.DirectShow;
using CompatibilityBarcodeReader = ZXing.Windows.Compatibility.BarcodeReader;
using CompatibilityBarcodeWriter = ZXing.Windows.Compatibility.BarcodeWriter;
using VideoResolution = AForge.Video.DirectShow.VideoCapabilities;

namespace FlashProgrammer;

public class QrCodeScanner : IDisposable
{
    private readonly CompatibilityBarcodeReader _barcodeReader;
    private System.Windows.Forms.Timer? _scanTimer;
    private PictureBox? _previewBox;
    private bool _isScanning = false;
    
    // 摄像头捕获相关
    private FilterInfoCollection? _videoDevices;
    private VideoCaptureDevice? _videoSource;
    private bool _cameraRunning = false;
    private Logger? _logger;
    
    public event EventHandler<QrCodeScannedEventArgs>? QrCodeScanned;
    public event EventHandler<string>? ScanError;
    public event EventHandler<bool>? CameraStateChanged;
    
    public QrCodeScanner()
    {
        _barcodeReader = new CompatibilityBarcodeReader
        {
            AutoRotate = true,
            Options = new DecodingOptions
            {
                TryHarder = true,
                TryInverted = true,
                PossibleFormats = new[] { BarcodeFormat.QR_CODE }
            }
        };
    }
    
    public void SetLogger(Logger logger)
    {
        _logger = logger;
    }
    
    public void StartCameraScan(PictureBox previewBox, int interval = 200)
    {
        if (_isScanning) return;
        
        _previewBox = previewBox;
        _scanTimer = new System.Windows.Forms.Timer();
        _scanTimer.Interval = interval;
        _scanTimer.Tick += ScanTimer_Tick;
        _scanTimer.Start();
        _isScanning = true;
    }
    
    public void StopCameraScan()
    {
        if (!_isScanning) return;
        
        if (_scanTimer != null)
        {
            _scanTimer.Stop();
            _scanTimer.Tick -= ScanTimer_Tick;
            _scanTimer.Dispose();
            _scanTimer = null;
        }
        _isScanning = false;
    }
    
    private void ScanTimer_Tick(object? sender, EventArgs e)
    {
        if (_previewBox == null || _previewBox.Image == null) return;
        
        try
        {
            var result = _barcodeReader.Decode((Bitmap)_previewBox.Image);
            if (result != null && !string.IsNullOrEmpty(result.Text))
            {
                QrCodeScanned?.Invoke(this, new QrCodeScannedEventArgs(result.Text));
            }
        }
        catch (Exception ex)
        {
            ScanError?.Invoke(this, $"扫描失败: {ex.Message}");
        }
    }
    
    public string? ScanFromBitmap(Bitmap bitmap)
    {
        try
        {
            var result = _barcodeReader.Decode(bitmap);
            return result?.Text;
        }
        catch (Exception ex)
        {
            ScanError?.Invoke(this, $"扫描失败: {ex.Message}");
            return null;
        }
    }
    
    public static Bitmap GenerateQrCode(string content, int width = 140, int height = 140)
    {
        var writer = new CompatibilityBarcodeWriter
        {
            Format = BarcodeFormat.QR_CODE,
            Options = new EncodingOptions
            {
                Width = width,
                Height = height,
                Margin = 1
            }
        };
        return writer.Write(content);
    }
    
    public static bool ParseQrCodeContent(string qrCodeContent, out int channelNumber, out string productInfo)
    {
        channelNumber = 0;
        productInfo = qrCodeContent;
        
        if (string.IsNullOrEmpty(qrCodeContent)) return false;
        
        if (qrCodeContent.StartsWith("CH", StringComparison.OrdinalIgnoreCase))
        {
            var parts = qrCodeContent.Split(new[] { ':', '-', '_' }, 2);
            if (parts.Length >= 1 && int.TryParse(parts[0].Substring(2), out int ch))
            {
                channelNumber = ch;
                productInfo = parts.Length > 1 ? parts[1] : qrCodeContent;
                return true;
            }
        }
        
        foreach (var sep in new[] { ':', '-', '_' })
        {
            if (qrCodeContent.Contains(sep))
            {
                var parts = qrCodeContent.Split(sep, 2);
                if (int.TryParse(parts[0].Trim(), out int ch))
                {
                    channelNumber = ch;
                    productInfo = parts.Length > 1 ? parts[1] : qrCodeContent;
                    return true;
                }
            }
        }
        
        return false;
    }
    
    public static string[] GetAvailableCameras()
    {
        try
        {
            var devices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            if (devices.Count == 0)
            {
                return new[] { "未找到摄像头" };
            }
            return Array.ConvertAll(devices.Cast<FilterInfo>().ToArray(), d => d.Name);
        }
        catch
        {
            return new[] { "未找到摄像头" };
        }
    }
    
    public void StartCameraCapture(PictureBox previewBox, int cameraIndex = 0, int scanInterval = 200)
    {
        if (_cameraRunning) return;
        
        try
        {
            _videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            
            if (_videoDevices.Count == 0)
            {
                ScanError?.Invoke(this, "未找到可用摄像头");
                return;
            }
            
            if (cameraIndex < 0 || cameraIndex >= _videoDevices.Count)
            {
                cameraIndex = 0;
            }
            
            _videoSource = new VideoCaptureDevice(_videoDevices[cameraIndex].MonikerString);
            _videoSource.NewFrame += VideoSource_NewFrame;
            _videoSource.VideoResolution = GetOptimalResolution(_videoSource);
            
            _previewBox = previewBox;
            _previewBox.SizeMode = PictureBoxSizeMode.StretchImage;
            
            _videoSource.Start();
            _cameraRunning = true;
            CameraStateChanged?.Invoke(this, true);
            
            StartCameraScan(previewBox, scanInterval);
            
            _logger?.Info("摄像头已启动");
        }
        catch (Exception ex)
        {
            ScanError?.Invoke(this, "启动摄像头失败: " + ex.Message);
        }
    }
    
    private VideoResolution? GetOptimalResolution(VideoCaptureDevice device)
    {
        foreach (var res in device.VideoCapabilities)
        {
            if (res.FrameSize.Width == 640 && res.FrameSize.Height == 480)
                return res;
        }
        
        VideoResolution? bestRes = null;
        foreach (var res in device.VideoCapabilities)
        {
            if (bestRes == null || 
                res.FrameSize.Width * res.FrameSize.Height > 
                bestRes.FrameSize.Width * bestRes.FrameSize.Height)
            {
                bestRes = res;
            }
        }
        return bestRes;
    }
    
    private void VideoSource_NewFrame(object? sender, NewFrameEventArgs eventArgs)
    {
        try
        {
            if (_previewBox != null)
            {
                Bitmap frame = (Bitmap)eventArgs.Frame.Clone();
                
                if (_previewBox.InvokeRequired)
                {
                    _previewBox.Invoke(new Action(() =>
                    {
                        _previewBox.Image = frame;
                    }));
                }
                else
                {
                    _previewBox.Image = frame;
                }
            }
        }
        catch { }
    }
    
    public void StopCameraCapture()
    {
        _cameraRunning = false;
        
        if (_videoSource != null)
        {
            _videoSource.NewFrame -= VideoSource_NewFrame;
            
            if (_videoSource.IsRunning)
            {
                _videoSource.SignalToStop();
                _videoSource.WaitForStop();
            }
            
            _videoSource = null;
        }
        
        _videoDevices = null;
        
        if (_previewBox != null)
        {
            _previewBox.Image = null;
        }
        
        CameraStateChanged?.Invoke(this, false);
        _logger?.Info("摄像头已停止");
    }
    
    public void Dispose()
    {
        StopCameraCapture();
        StopCameraScan();
        _previewBox = null;
    }
}

public class QrCodeScannedEventArgs : EventArgs
{
    public string QrCodeContent { get; }
    public DateTime ScanTime { get; }
    
    public QrCodeScannedEventArgs(string qrCodeContent)
    {
        QrCodeContent = qrCodeContent;
        ScanTime = DateTime.Now;
    }
}
