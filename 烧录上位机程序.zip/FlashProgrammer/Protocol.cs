using System;
using System.Collections.Generic;
using System.Linq;

namespace FlashProgrammer;

/// <summary>
/// 协议帧头定义（十六进制）
/// 严格遵循协议规范定义的帧头类型
/// </summary>
public enum FrameHeader : byte
{
    // 基础通信指令
    HandshakeRequest = 0xAA,      // 上位机→下位机：握手请求
    HandshakeResponse = 0xBB,     // 下位机→上位机：握手响应
    FileInfoRequest = 0xCC,       // 上位机→下位机：发送文件信息
    FileInfoResponse = 0xDD,      // 下位机→上位机：回复文件信息
    FirmwareData = 0xEE,          // 上位机→下位机：传输固件数据
    FirmwareResponse = 0xFF,      // 下位机→上位机：固件传输响应
    FirmwareComplete = 0x11,      // 下位机→上位机：固件接收完成
    ProgramComplete = 0x22,       // 下位机→上位机：烧写完成
    ErrorReport = 0x33,           // 下位机→上位机：通信/业务错误
    ReadDeviceId = 0x44,          // 上位机→下位机：读取设备ID
    DeviceIdResponse = 0x55,      // 下位机→上位机：返回设备ID
    
    // 文件管理指令
    ReadAllFiles = 0xA1,          // 上位机→下位机：读取全部文件记录
    AllFilesResponse = 0xB1,      // 下位机→上位机：返回全部文件记录
    ReadSingleFile = 0xA2,        // 上位机→下位机：读取单个文件记录
    SingleFileResponse = 0xB2,    // 下位机→上位机：返回单个文件信息
    DeleteSingleFile = 0xA3,      // 上位机→下位机：删除单个文件
    DeleteSingleResponse = 0xB3,  // 下位机→上位机：单文件删除响应
    DeleteAllFiles = 0xA4,        // 上位机→下位机：删除全部文件
    DeleteAllResponse = 0xB4,     // 下位机→上位机：全部文件删除响应
    ReadDeviceInfo = 0xA5,        // 上位机→下位机：读取设备类型与版本
    DeviceInfoResponse = 0xB5,    // 下位机→上位机：返回设备版本信息
    
    // 烧录控制指令
    StartProgram = 0xA8,          // 上位机→下位机：开始烧录
    ProgramConfirm = 0xB8,        // 下位机→上位机：确认启动烧录
    QueryFileName = 0xA9,         // 上位机→下位机：查询当前烧录文件名
    FileNameResponse = 0xB9,      // 下位机→上位机：返回当前烧录文件名
    SelectFileByName = 0xC0,      // 上位机→下位机：通过文件名选择文件
    FileNameSelectResponse = 0xD0,// 下位机→上位机：确认文件名选择结果
    SelectFileByIndex = 0xC1,     // 上位机→下位机：通过文件序号选择文件
    FileIndexSelectResponse = 0xD1,//下位机→上位机：确认文件序号选择结果
    QueryProgress = 0xC2,         // 上位机→下位机：请求查询烧录进度
    ProgressResponse = 0xD2,      // 下位机→上位机：实时反馈烧录进度
    EraseCommand = 0xC3,          // 上位机→下位机：单独擦除指令
    EraseConfirm = 0xD3,          // 下位机→上位机：确认擦除指令
    SetSpeed = 0xC4,              // 上位机→下位机：修改烧录速度
    SpeedConfirm = 0xD4,          // 下位机→上位机：确认速度修改
    SetSerialNumber = 0xC5,       // 上位机→下位机：修改序列号、烧录次数
    SerialNumberConfirm = 0xD5,   // 下位机→上位机：确认序列号修改
    ReadFileCrc = 0xC6,          // 上位机→下位机：读取文件CRC校验值
    FileCrcResponse = 0xD6,       // 下位机→上位机：返回文件CRC校验值
    
    // 程序读写指令
    ReadProgram = 0x3E,           // 上位机→下位机：程序读取指令
    ReadProgramResponse = 0x3F,   // 下位机→上位机：程序读取响应
    ReadProgramData = 0x41,       // 上位机→下位机：程序数据包读取指令
    ProgramDataResponse = 0x42,   // 下位机→上位机：返回程序数据包
    EraseSingle = 0x69,           // 上位机→下位机：单独擦除指令
    EraseSingleConfirm = 0x6A,    // 下位机→上位机：确认单独擦除完成
    ProgramSingle = 0x6B,         // 上位机→下位机：单独编程烧录指令
    ProgramSingleConfirm = 0x6C,  // 下位机→上位机：确认单独编程完成
    VerifySingle = 0x6D,          // 上位机→下位机：单独数据校验指令
    VerifySingleConfirm = 0x6F,   // 下位机→上位机：确认单独校验完成
    
    // 批量操作指令
    ExecuteAll = 0x70,            // 上位机→下位机：全部执行（擦除+烧录+校验）
    ExecuteAllConfirm = 0x71,     // 下位机→上位机：确认全部指令执行
    ProgramAtAddress = 0x72,      // 上位机→下位机：指定地址烧录指令
    AddressProgramConfirm = 0x73  // 下位机→上位机：确认指定地址烧录
}

/// <summary>
/// 烧录状态码定义（通过0xD2进度反馈包上报）
/// </summary>
public enum ProgramStatus : byte
{
    ReadComplete = 0x11,          // 读取数据完成，进入烧录准备阶段
    InitComplete = 0x22,          // 初始化准备完成
    ProtectionRemoved = 0x33,     // 解除程序读保护成功
    Erasing = 0x44,               // 正在执行芯片擦除
    EraseComplete = 0x55,         // 芯片擦除完成
    Programming = 0x66,           // 正在执行固件编程
    ProgramComplete = 0x77,       // 固件编程完成
    Verifying = 0x88,             // 正在执行数据校验
    VerifyComplete = 0x99,        // 数据校验完成
    
    // 错误状态
    ConnectFailed = 0xAA,         // 连接失败，通信异常
    EraseFailed = 0xBB,           // 芯片擦除失败
    ProgramFailed = 0xCC,         // 固件编程失败
    VerifyFailed = 0xDD,          // 固件校验失败
    ProgramCountExhausted = 0xEE, // 烧录次数耗尽
    VoltageError = 0xFF           // 设备电压异常
}

/// <summary>
/// 协议数据包结构
/// 遵循协议规范：帧头(1) + 长度(1) + 编号(2) + 数据(n) + 校验(2)
/// 最大长度：64字节
/// </summary>
public class ProtocolPacket
{
    /// <summary>
    /// 帧头：数据包类型标识
    /// </summary>
    public FrameHeader Header { get; set; }
    
    /// <summary>
    /// 编号：数据包序号（多包传输）或通道号（多通道烧录）
    /// </summary>
    public ushort Number { get; set; }
    
    /// <summary>
    /// 数据：业务数据内容
    /// </summary>
    public byte[] Data { get; set; } = Array.Empty<byte>();
    
    /// <summary>
    /// 校验值：CRC16-MODBUS
    /// </summary>
    public ushort Checksum { get; set; }
    
    /// <summary>
    /// 计算数据包总长度
    /// </summary>
    public int TotalLength => 1 + 1 + 2 + Data.Length + 2;
    
    /// <summary>
    /// 检查数据包是否超过最大长度限制
    /// </summary>
    public bool IsValidLength => TotalLength <= 64;
}

/// <summary>
/// CRC16-MODBUS 校验算法
/// 严格遵循协议规范要求
/// </summary>
public static class Crc16Modbus
{
    private const ushort Polynomial = 0xA001;
    private static readonly ushort[] CrcTable = new ushort[256];
    
    static Crc16Modbus()
    {
        // 预计算CRC表
        for (ushort i = 0; i < 256; i++)
        {
            ushort crc = 0;
            ushort byteVal = i;
            for (int j = 0; j < 8; j++)
            {
                bool lsb = (crc & 0x0001) != 0;
                crc >>= 1;
                if (lsb)
                    crc ^= Polynomial;
                bool dataLsb = (byteVal & 0x0001) != 0;
                byteVal >>= 1;
                if (dataLsb)
                    crc ^= Polynomial;
            }
            CrcTable[i] = crc;
        }
    }
    
    /// <summary>
    /// 计算CRC16-MODBUS校验值
    /// </summary>
    /// <param name="data">待校验数据</param>
    /// <returns>CRC16校验值</returns>
    public static ushort Calculate(byte[] data)
    {
        ushort crc = 0xFFFF;
        foreach (byte b in data)
        {
            crc = (ushort)((crc >> 8) ^ CrcTable[(crc ^ b) & 0xFF]);
        }
        return crc;
    }
    
    /// <summary>
    /// 计算CRC16-MODBUS校验值（带初始值）
    /// </summary>
    public static ushort Calculate(byte[] data, int offset, int length)
    {
        ushort crc = 0xFFFF;
        for (int i = offset; i < offset + length; i++)
        {
            crc = (ushort)((crc >> 8) ^ CrcTable[(crc ^ data[i]) & 0xFF]);
        }
        return crc;
    }
}

/// <summary>
/// 协议封包器
/// 负责将数据封装为符合协议规范的数据包
/// </summary>
public static class ProtocolPacker
{
    /// <summary>
    /// 最大数据包长度
    /// </summary>
    public const int MaxPacketLength = 64;
    
    /// <summary>
    /// 封装数据包
    /// </summary>
    /// <param name="header">帧头</param>
    /// <param name="number">编号（通道号或包序号）</param>
    /// <param name="data">业务数据</param>
    /// <returns>完整的字节数组数据包</returns>
    public static byte[] Pack(FrameHeader header, ushort number, byte[] data)
    {
        // 计算总长度
        int totalLength = 1 + 1 + 2 + data.Length + 2;
        
        // 检查长度限制
        if (totalLength > MaxPacketLength)
        {
            throw new ArgumentException($"数据包长度 {totalLength} 超过最大限制 {MaxPacketLength} 字节");
        }
        
        // 构建数据包
        byte[] packet = new byte[totalLength];
        int offset = 0;
        
        // 帧头 (1字节)
        packet[offset++] = (byte)header;
        
        // 长度 (1字节)
        packet[offset++] = (byte)totalLength;
        
        // 编号 (2字节, 小端序)
        packet[offset++] = (byte)(number & 0xFF);
        packet[offset++] = (byte)((number >> 8) & 0xFF);
        
        // 数据 (n字节)
        Buffer.BlockCopy(data, 0, packet, offset, data.Length);
        offset += data.Length;
        
        // 计算并添加CRC校验 (2字节, 小端序)
        ushort crc = Crc16Modbus.Calculate(packet, 0, offset);
        packet[offset++] = (byte)(crc & 0xFF);
        packet[offset] = (byte)((crc >> 8) & 0xFF);
        
        return packet;
    }
    
    /// <summary>
    /// 封装数据包（字符串数据）
    /// </summary>
    public static byte[] Pack(FrameHeader header, ushort number, string data)
    {
        byte[] dataBytes = System.Text.Encoding.ASCII.GetBytes(data);
        return Pack(header, number, dataBytes);
    }
    
    /// <summary>
    /// 封装数据包（无业务数据）
    /// </summary>
    public static byte[] Pack(FrameHeader header, ushort number)
    {
        return Pack(header, number, Array.Empty<byte>());
    }
    
    /// <summary>
    /// 封装握手请求包
    /// </summary>
    public static byte[] PackHandshakeRequest(ushort channelNumber = 0)
    {
        return Pack(FrameHeader.HandshakeRequest, channelNumber);
    }
    
    /// <summary>
    /// 封装开始烧录指令（单通道）
    /// </summary>
    public static byte[] PackStartProgram(ushort channelNumber)
    {
        return Pack(FrameHeader.StartProgram, channelNumber);
    }

    /// <summary>
    /// 封装开始烧录指令（多通道广播）
    /// 帧形态：A8 08 [maskLo] [maskHi] [paramLo] [paramHi] [crcLo] [crcHi]
    /// 例如 12 路全开：mask=0x0FFF，param=0x0000 => A8 08 FF 0F 00 00 xx xx
    /// </summary>
    public static byte[] PackStartProgramBroadcast(ushort channelMask, ushort param = 0)
    {
        byte[] data = new[] { (byte)(param & 0xFF), (byte)((param >> 8) & 0xFF) };
        return Pack(FrameHeader.StartProgram, channelMask, data);
    }
    
    /// <summary>
    /// 封装查询烧录进度指令
    /// </summary>
    public static byte[] PackQueryProgress(ushort channelNumber)
    {
        return Pack(FrameHeader.QueryProgress, channelNumber);
    }

    /// <summary>
    /// 封装查询当前烧录文件名指令
    /// </summary>
    public static byte[] PackQueryFileName(ushort channelNumber)
    {
        return Pack(FrameHeader.QueryFileName, channelNumber);
    }
    
    /// <summary>
    /// 封装选择烧录文件指令（通过序号）
    /// </summary>
    public static byte[] PackSelectFileByIndex(ushort channelNumber, ushort fileIndex)
    {
        byte[] data = new[] { (byte)(fileIndex & 0xFF), (byte)((fileIndex >> 8) & 0xFF) };
        return Pack(FrameHeader.SelectFileByIndex, channelNumber, data);
    }
    
    /// <summary>
    /// 封装读取设备ID指令
    /// </summary>
    public static byte[] PackReadDeviceId(ushort channelNumber)
    {
        return Pack(FrameHeader.ReadDeviceId, channelNumber);
    }
    
    /// <summary>
    /// 封装执行全部指令（擦除+烧录+校验）
    /// </summary>
    public static byte[] PackExecuteAll(ushort channelNumber)
    {
        return Pack(FrameHeader.ExecuteAll, channelNumber);
    }
    
    /// <summary>
    /// 封装读取设备信息指令
    /// </summary>
    public static byte[] PackReadDeviceInfo(ushort channelNumber)
    {
        return Pack(FrameHeader.ReadDeviceInfo, channelNumber);
    }
}

/// <summary>
/// 协议解包器
/// 负责解析接收到的原始数据，提取有效数据包
/// </summary>
public static class ProtocolUnpacker
    {
        /// <summary>
        /// 最大数据包长度限制
        /// </summary>
        private const int MaxPacketLength = 1024;
        
        /// <summary>
        /// 解析原始数据，提取完整的数据包列表
        /// </summary>
        /// <param name="rawData">原始字节数据</param>
        /// <param name="remainingData">未处理完的数据（用于拼接）</param>
        /// <returns>解析出的数据包列表</returns>
        public static List<ProtocolPacket> Unpack(byte[] rawData, ref byte[] remainingData)
        {
            List<ProtocolPacket> packets = new List<ProtocolPacket>();
            
            // 将剩余数据与新数据合并
            byte[] combinedData = new byte[remainingData.Length + rawData.Length];
            Buffer.BlockCopy(remainingData, 0, combinedData, 0, remainingData.Length);
            Buffer.BlockCopy(rawData, 0, combinedData, remainingData.Length, rawData.Length);
            
            int offset = 0;
            
            while (offset + 6 <= combinedData.Length) // 最小包长：帧头(1)+长度(1)+编号(2)+数据(0)+校验(2) = 6
            {
                // 读取帧头
                FrameHeader header = (FrameHeader)combinedData[offset];
                
                // 读取长度
                int packetLength = combinedData[offset + 1];
                
                // 检查长度是否有效
                if (packetLength < 6 || packetLength > MaxPacketLength)
                {
                    // 无效长度，跳过一个字节继续解析
                    offset++;
                    continue;
                }
                
                // 检查是否有足够的数据
                if (offset + packetLength > combinedData.Length)
                {
                    // 数据不完整，等待后续数据
                    break;
                }
                
                // 验证CRC校验
                ushort receivedCrc = (ushort)(combinedData[offset + packetLength - 2] | 
                                             (combinedData[offset + packetLength - 1] << 8));
                ushort calculatedCrc = Crc16Modbus.Calculate(combinedData, offset, packetLength - 2);
                
                if (receivedCrc != calculatedCrc)
                {
                    // CRC校验失败，跳过一个字节继续解析
                    offset++;
                    continue;
                }
                
                // 解析编号（小端序）
                ushort number = (ushort)(combinedData[offset + 2] | 
                                        (combinedData[offset + 3] << 8));
                
                // 提取数据部分
                int dataLength = packetLength - 6; // 减去帧头、长度、编号、校验的长度
                byte[] data = new byte[dataLength];
                if (dataLength > 0)
                {
                    Buffer.BlockCopy(combinedData, offset + 4, data, 0, dataLength);
                }
                
                // 创建数据包对象
                packets.Add(new ProtocolPacket
                {
                    Header = header,
                    Number = number,
                    Data = data,
                    Checksum = receivedCrc
                });
                
                // 移动到下一个数据包
                offset += packetLength;
            }
        
        // 保存未处理完的数据
        if (offset < combinedData.Length)
        {
            remainingData = new byte[combinedData.Length - offset];
            Buffer.BlockCopy(combinedData, offset, remainingData, 0, remainingData.Length);
        }
        else
        {
            remainingData = Array.Empty<byte>();
        }
        
        return packets;
    }
    
    /// <summary>
    /// 解析原始数据（简化版，不保留剩余数据）
    /// </summary>
    public static List<ProtocolPacket> Unpack(byte[] rawData)
    {
        byte[] remaining = Array.Empty<byte>();
        return Unpack(rawData, ref remaining);
    }
    
    /// <summary>
    /// 解析进度响应包，提取状态码和进度
    /// </summary>
    /// <param name="packet">进度响应包（0xD2）</param>
    /// <param name="status">解析出的烧录状态</param>
    /// <param name="progress">解析出的烧录进度（0-100）</param>
    /// <returns>是否解析成功</returns>
    public static bool ParseProgressPacket(ProtocolPacket packet, out ProgramStatus status, out int progress, int activeChannelCount = 1)
    {
        status = ProgramStatus.ConnectFailed;
        progress = 0;

        if (packet.Header != FrameHeader.ProgressResponse)
        {
            return false;
        }

        if (packet.Data.Length >= 2)
        {
            status = (ProgramStatus)packet.Data[0];
            progress = packet.Data[1];
            if (progress < 0) progress = 0;
            if (progress > 100) progress = 100;
            return true;
        }

            if (packet.Data.Length == 0)
        {
            byte lowByte = (byte)(packet.Number & 0xFF);
            byte highByte = (byte)((packet.Number >> 8) & 0xFF);

            bool isMultiChannelMode = activeChannelCount > 1;

            // 多通道模式按现场协议解析：
            // 第 1 字节从 0 开始计数，0x00~0x(N-1) 依次表示通道 1~N；第 2 字节为状态码。
            if (isMultiChannelMode && lowByte < activeChannelCount && highByte >= 0x11)
            {
                status = (ProgramStatus)highByte;
                if (status == ProgramStatus.EraseComplete ||
                    status == ProgramStatus.ProgramComplete ||
                    status == ProgramStatus.VerifyComplete)
                {
                    progress = 100;
                }
                else
                {
                    progress = 0;
                }
                return true;
            }

            // 单通道模式下兼容低字节为通道号、高字节为状态码的旧格式。
            if (!isMultiChannelMode && lowByte >= 1 && lowByte <= activeChannelCount && highByte >= 0x11)
            {
                status = (ProgramStatus)highByte;
                // 对于特定的完成状态，我们手动将进度设为 100
                if (status == ProgramStatus.EraseComplete || 
                    status == ProgramStatus.ProgramComplete || 
                    status == ProgramStatus.VerifyComplete)
                {
                    progress = 100;
                }
                else
                {
                    progress = 0; // 如果没有具体进度字节，默认报 0
                }
                return true;
            }

            // 单通道模式下兼容原有汇总帧（低字节为0）。
            if (!isMultiChannelMode && lowByte == 0 && highByte >= 0x11)
            {
                status = (ProgramStatus)highByte;
                progress = 0;
                return true;
            }

            if (lowByte >= 0x11)
            {
                status = (ProgramStatus)lowByte;
                progress = highByte;
                if (progress < 0) progress = 0;
                if (progress > 100) progress = 100;
                return true;
            }

            if (isMultiChannelMode && highByte >= 0x11)
            {
                status = (ProgramStatus)highByte;
                progress = 0;
                return true;
            }

            return false;
        }

        return false;
    }
    
    /// <summary>
    /// 解析设备ID响应包
    /// </summary>
    public static string ParseDeviceIdPacket(ProtocolPacket packet)
    {
        if (packet.Header != FrameHeader.DeviceIdResponse)
            return string.Empty;
        
        return System.Text.Encoding.ASCII.GetString(packet.Data).Trim('\0');
    }
    
    /// <summary>
    /// 解析设备信息响应包
    /// </summary>
    public static string ParseDeviceInfoPacket(ProtocolPacket packet)
    {
        if (packet.Header != FrameHeader.DeviceInfoResponse)
            return string.Empty;
        
        return System.Text.Encoding.ASCII.GetString(packet.Data).Trim('\0');
    }

    /// <summary>
    /// 解析当前烧录文件名响应包
    /// </summary>
    public static string ParseFileNamePacket(ProtocolPacket packet)
    {
        if (packet.Header != FrameHeader.FileNameResponse)
            return string.Empty;

        return System.Text.Encoding.ASCII.GetString(packet.Data).Trim('\0').Trim();
    }
    
    /// <summary>
    /// 解析错误报告包
    /// </summary>
    public static string ParseErrorPacket(ProtocolPacket packet)
    {
        if (packet.Header != FrameHeader.ErrorReport)
            return string.Empty;
        
        return System.Text.Encoding.ASCII.GetString(packet.Data).Trim('\0');
    }
}

/// <summary>
/// 协议指令帮助类
/// 提供常用指令的便捷封装方法
/// </summary>
public static class ProtocolCommands
{
    /// <summary>
    /// 创建握手指令包
    /// </summary>
    public static byte[] Handshake(ushort channel = 0) => ProtocolPacker.PackHandshakeRequest(channel);
    
    /// <summary>
    /// 创建开始烧录指令包（单通道）
    /// </summary>
    public static byte[] StartProgram(ushort channel) => ProtocolPacker.PackStartProgram(channel);

    /// <summary>
    /// 创建开始烧录指令包（多通道广播）
    /// </summary>
    public static byte[] StartProgramBroadcast(ushort channelMask, ushort param = 0) => ProtocolPacker.PackStartProgramBroadcast(channelMask, param);
    
    /// <summary>
    /// 创建查询进度指令包
    /// </summary>
    public static byte[] QueryProgress(ushort channel) => ProtocolPacker.PackQueryProgress(channel);
    
    /// <summary>
    /// 创建查询当前烧录文件名指令包
    /// </summary>
    public static byte[] QueryFileName(ushort channel) => ProtocolPacker.PackQueryFileName(channel);

    /// <summary>
    /// 创建执行全部指令包（擦除+烧录+校验）
    /// </summary>
    public static byte[] ExecuteAll(ushort channel) => ProtocolPacker.PackExecuteAll(channel);
    
    /// <summary>
    /// 创建读取设备ID指令包
    /// </summary>
    public static byte[] ReadDeviceId(ushort channel) => ProtocolPacker.PackReadDeviceId(channel);
    
    /// <summary>
    /// 创建读取设备信息指令包
    /// </summary>
    public static byte[] ReadDeviceInfo(ushort channel) => ProtocolPacker.PackReadDeviceInfo(channel);
    
    /// <summary>
    /// 创建选择文件指令包（通过序号）
    /// </summary>
    public static byte[] SelectFile(ushort channel, ushort fileIndex) => ProtocolPacker.PackSelectFileByIndex(channel, fileIndex);
    
    /// <summary>
    /// 创建读取全部文件列表指令包
    /// </summary>
    public static byte[] ReadAllFiles(ushort channel) => ProtocolPacker.Pack(FrameHeader.ReadAllFiles, channel);
    
    /// <summary>
    /// 创建删除全部文件指令包
    /// </summary>
    public static byte[] DeleteAllFiles(ushort channel) => ProtocolPacker.Pack(FrameHeader.DeleteAllFiles, channel);
    
    /// <summary>
    /// 创建单独擦除指令包
    /// </summary>
    public static byte[] Erase(ushort channel) => ProtocolPacker.Pack(FrameHeader.EraseCommand, channel);
    
    /// <summary>
    /// 创建单独编程指令包
    /// </summary>
    public static byte[] Program(ushort channel) => ProtocolPacker.Pack(FrameHeader.ProgramSingle, channel);
    
    /// <summary>
    /// 创建单独校验指令包
    /// </summary>
    public static byte[] Verify(ushort channel) => ProtocolPacker.Pack(FrameHeader.VerifySingle, channel);
}
