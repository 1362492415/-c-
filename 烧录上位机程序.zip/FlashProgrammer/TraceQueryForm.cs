using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FlashProgrammer;

public class TraceQueryForm : Form
{
    private readonly TraceabilityRepository _repository;
    private readonly Logger? _logger;

    private readonly TextBox _txtScanInput;
    private readonly Label _lblCurrentQr;
    private readonly TextBox _txtLatestSummary;
    private readonly DataGridView _gridHistory;
    private readonly Label _lblStatus;
    private readonly System.Windows.Forms.Timer _autoSubmitTimer;
    private readonly Label _lblInputHint;
    private bool _isQuerying;

    public TraceQueryForm(TraceabilityRepository repository, Logger? logger = null)
    {
        _repository = repository;
        _logger = logger;

        Text = "二维码追溯查询";
        Size = new Size(1080, 720);
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(980, 620);

        var lblHint = new Label
        {
            Text = "请使用扫码枪扫描二维码，系统会自动查询该二维码的全部烧录历史。",
            Location = new Point(20, 18),
            Size = new Size(1020, 44),
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };

        _lblInputHint = new Label
        {
            Text = "扫码内容：",
            Location = new Point(20, 72),
            Size = new Size(90, 28),
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold)
        };

        _txtScanInput = new TextBox
        {
            Location = new Point(110, 67),
            Size = new Size(930, 35),
            Font = new Font("Microsoft YaHei UI", 12F),
            BorderStyle = BorderStyle.FixedSingle,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };

        _autoSubmitTimer = new System.Windows.Forms.Timer { Interval = 500 };
        _autoSubmitTimer.Tick += (s, e) => {
            _autoSubmitTimer.Stop();
            string code = _txtScanInput.Text.Trim();
            if (!string.IsNullOrWhiteSpace(code)) {
                QueryQrCode(code);
            }
        };

        _lblCurrentQr = new Label
        {
            Text = "当前二维码：",
            Location = new Point(20, 116),
            Size = new Size(1020, 52),
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold),
            BorderStyle = BorderStyle.FixedSingle,
            Padding = new Padding(8, 6, 8, 6),
            TextAlign = ContentAlignment.MiddleLeft,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };

        _lblStatus = new Label
        {
            Text = "等待扫码...",
            Location = new Point(20, 176),
            Size = new Size(1020, 30),
            Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular),
            ForeColor = Color.FromArgb(41, 128, 185),
            TextAlign = ContentAlignment.MiddleLeft,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };

        _txtLatestSummary = new TextBox
        {
            Text = "最新记录：暂无",
            Location = new Point(20, 214),
            Size = new Size(1020, 140),
            Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular),
            BorderStyle = BorderStyle.FixedSingle,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            BackColor = Color.White,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };

        _gridHistory = new DataGridView
        {
            Location = new Point(20, 370),
            Size = new Size(1020, 292),
            ReadOnly = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
            BackgroundColor = Color.White,
            RowHeadersVisible = false,
            ScrollBars = ScrollBars.Both,
            Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
        };

        _gridHistory.Columns.Add("StartTime", "开始时间");
        _gridHistory.Columns.Add("Result", "结果");
        _gridHistory.Columns.Add("StatusCode", "状态码");
        _gridHistory.Columns.Add("StatusText", "状态说明");
        _gridHistory.Columns.Add("ChannelNumber", "通道");
        _gridHistory.Columns.Add("FirmwareName", "固件名");
        _gridHistory.Columns.Add("PortName", "串口");
        _gridHistory.Columns.Add("BatchId", "批次号");
        _gridHistory.Columns.Add("DurationMs", "耗时(ms)");
        _gridHistory.Columns.Add("ErrorMessage", "错误信息");
        _gridHistory.Columns["ErrorMessage"]!.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

        Controls.Add(lblHint);
        Controls.Add(_lblInputHint);
        Controls.Add(_txtScanInput);
        Controls.Add(_lblCurrentQr);
        Controls.Add(_lblStatus);
        Controls.Add(_txtLatestSummary);
        Controls.Add(_gridHistory);

        KeyPreview = true;
        Load += (_, _) => FocusScanInput();
        Shown += (_, _) => FocusScanInput();
        Activated += (_, _) => FocusScanInput();
        FormDisplayHelper.FitToWorkingArea(this, new Size(1080, 720), new Size(900, 560));
        _txtScanInput.KeyDown += TxtScanInput_KeyDown;
        _txtScanInput.TextChanged += (s, e) => {
            if (_isQuerying)
            {
                return;
            }
            _autoSubmitTimer.Stop();
            if (!string.IsNullOrWhiteSpace(_txtScanInput.Text)) {
                _lblStatus.Text = "已识别内容，0.5 秒后自动查询...";
                _lblStatus.ForeColor = Color.DarkOrange;
                _autoSubmitTimer.Start();
            }
            else
            {
                _lblStatus.Text = "等待扫码...";
                _lblStatus.ForeColor = Color.FromArgb(41, 128, 185);
            }
        };
        Click += (_, _) => FocusScanInput();
        _gridHistory.Click += (_, _) => FocusScanInput();
        _txtLatestSummary.Click += (_, _) => FocusScanInput();
        _lblCurrentQr.Click += (_, _) => FocusScanInput();
        _lblStatus.Click += (_, _) => FocusScanInput();
    }

    private void TxtScanInput_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode != Keys.Enter)
        {
            return;
        }

        e.SuppressKeyPress = true;
        SubmitCurrentInput();
    }

    private void QueryQrCode(string qrCode)
    {
        _isQuerying = true;
        _autoSubmitTimer.Stop();
        _lblCurrentQr.Text = $"当前二维码：{qrCode}";
        _gridHistory.Rows.Clear();

        try
        {
            var records = _repository.QueryByQrCode(qrCode);
            if (records.Count == 0)
            {
                _lblStatus.Text = "未找到该二维码的烧录记录。";
                _lblStatus.ForeColor = Color.FromArgb(192, 57, 43);
                _txtLatestSummary.Text = "最新记录：暂无";
                return;
            }

            var latest = records[0];
            _lblStatus.Text = $"共找到 {records.Count} 条历史记录。";
            _lblStatus.ForeColor = Color.FromArgb(39, 174, 96);
            _txtLatestSummary.Text = BuildLatestSummary(latest);

            foreach (var record in records)
            {
                _gridHistory.Rows.Add(
                    record.StartTime.ToString("yyyy-MM-dd HH:mm:ss"),
                    record.Result,
                    record.StatusCode,
                    record.StatusText,
                    record.ChannelNumber,
                    record.FirmwareName ?? string.Empty,
                    record.PortName ?? string.Empty,
                    record.BatchId ?? string.Empty,
                    record.DurationMs,
                    record.ErrorMessage ?? string.Empty);
            }

            _logger?.Info($"追溯查询成功: 二维码={qrCode}, 记录数={records.Count}");
        }
        catch (Exception ex)
        {
            _lblStatus.Text = "查询失败，请检查数据库。";
            _lblStatus.ForeColor = Color.FromArgb(192, 57, 43);
            _txtLatestSummary.Text = "最新记录：查询失败";
            _logger?.Error($"追溯查询失败: 二维码={qrCode}", ex);
        }
        finally
        {
            _isQuerying = false;
            FocusScanInput();
        }
    }

    private static string BuildLatestSummary(BurnRecord record)
    {
        return string.Join(Environment.NewLine, new[]
        {
            $"最新记录：{record.Result} / {record.StatusText} ({record.StatusCode})",
            $"开始时间：{record.StartTime:yyyy-MM-dd HH:mm:ss}    结束时间：{record.EndTime:yyyy-MM-dd HH:mm:ss}",
            $"耗时：{record.DurationMs} ms    通道：{record.ChannelNumber}    串口：{record.PortName ?? string.Empty}",
            $"固件名：{record.FirmwareName ?? string.Empty}    批次号：{record.BatchId ?? string.Empty}",
            $"设备信息：{record.DeviceInfo ?? string.Empty}",
            $"错误信息：{record.ErrorMessage ?? string.Empty}"
        });
    }

    private void FocusScanInput()
    {
        _txtScanInput.Focus();
        _txtScanInput.SelectAll();
    }

    private void SubmitCurrentInput()
    {
        _autoSubmitTimer.Stop();
        if (_isQuerying)
        {
            return;
        }

        string code = _txtScanInput.Text.Trim();
        if (string.IsNullOrWhiteSpace(code))
        {
            FocusScanInput();
            return;
        }

        QueryQrCode(code);
    }
}
