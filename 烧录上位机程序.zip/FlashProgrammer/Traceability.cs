﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;

namespace FlashProgrammer;

public class BurnRecord
{
    public long Id { get; set; }
    public string QrCode { get; set; } = string.Empty;
    public int ChannelNumber { get; set; }
    public string Result { get; set; } = string.Empty;
    public string StatusCode { get; set; } = string.Empty;
    public string StatusText { get; set; } = string.Empty;
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public long DurationMs { get; set; }
    public string? DeviceInfo { get; set; }
    public string? FirmwareName { get; set; }
    public string? PortName { get; set; }
    public string? BatchId { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsBatch { get; set; }
}

public class BurnTraceContext
{
    public int ChannelNumber { get; set; }
    public string QrCode { get; set; } = string.Empty;
    public DateTime StartTime { get; set; }
    public string? DeviceInfo { get; set; }
    public string? FirmwareName { get; set; }
    public string? PortName { get; set; }
    public string? BatchId { get; set; }
    public bool IsBatch { get; set; }
    public bool RecordSaved { get; set; }
}

public class TraceabilityRepository
{
    private readonly string _connectionString;
    private readonly Logger? _logger;

    public TraceabilityRepository(string connectionString, Logger? logger = null)
    {
        _connectionString = connectionString?.Trim() ?? string.Empty;
        _logger = logger;
    }

    public void Initialize()
    {
        try
        {
            if (string.IsNullOrWhiteSpace(_connectionString))
            {
                throw new InvalidOperationException("未配置 SQL Server 连接字符串，请先在 appsettings.json 中填写 TraceabilityConnectionString。");
            }

            using var connection = new SqlConnection(_connectionString);
            connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText =
                """
                IF OBJECT_ID(N'dbo.BurnRecords', N'U') IS NULL
                BEGIN
                    CREATE TABLE dbo.BurnRecords (
                        Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                        QrCode NVARCHAR(200) NOT NULL,
                        ChannelNumber INT NOT NULL,
                        Result NVARCHAR(32) NOT NULL,
                        StatusCode NVARCHAR(32) NOT NULL,
                        StatusText NVARCHAR(128) NOT NULL,
                        StartTime DATETIME2(3) NOT NULL,
                        EndTime DATETIME2(3) NOT NULL,
                        DurationMs BIGINT NOT NULL,
                        DeviceInfo NVARCHAR(512) NULL,
                        FirmwareName NVARCHAR(260) NULL,
                        PortName NVARCHAR(64) NULL,
                        BatchId NVARCHAR(64) NULL,
                        ErrorMessage NVARCHAR(512) NULL,
                        CreatedAt DATETIME2(3) NOT NULL
                            CONSTRAINT DF_BurnRecords_CreatedAt DEFAULT SYSDATETIME(),
                        IsBatch BIT NOT NULL
                            CONSTRAINT DF_BurnRecords_IsBatch DEFAULT 0
                    );
                END;

                IF NOT EXISTS (
                    SELECT 1
                    FROM sys.indexes
                    WHERE name = N'IX_BurnRecords_QrCode_StartTime'
                      AND object_id = OBJECT_ID(N'dbo.BurnRecords')
                )
                BEGIN
                    CREATE INDEX IX_BurnRecords_QrCode_StartTime
                    ON dbo.BurnRecords(QrCode, StartTime DESC);
                END;

                IF NOT EXISTS (
                    SELECT 1
                    FROM sys.indexes
                    WHERE name = N'IX_BurnRecords_BatchId'
                      AND object_id = OBJECT_ID(N'dbo.BurnRecords')
                )
                BEGIN
                    CREATE INDEX IX_BurnRecords_BatchId
                    ON dbo.BurnRecords(BatchId);
                END;

                IF NOT EXISTS (
                    SELECT 1
                    FROM sys.indexes
                    WHERE name = N'IX_BurnRecords_Result'
                      AND object_id = OBJECT_ID(N'dbo.BurnRecords')
                )
                BEGIN
                    CREATE INDEX IX_BurnRecords_Result
                    ON dbo.BurnRecords(Result);
                END;
                """;
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            _logger?.Error("初始化追溯数据库失败", ex);
            throw;
        }
    }

    public void SaveRecord(BurnRecord record)
    {
        using var connection = new SqlConnection(_connectionString);
        connection.Open();

        string qrCode = NormalizeQrCode(record.QrCode);
        if (string.IsNullOrWhiteSpace(qrCode))
        {
            throw new InvalidOperationException("二维码内容不能为空");
        }

        using var command = connection.CreateCommand();
        command.CommandText =
            """
            INSERT INTO dbo.BurnRecords (
                QrCode,
                ChannelNumber,
                Result,
                StatusCode,
                StatusText,
                StartTime,
                EndTime,
                DurationMs,
                DeviceInfo,
                FirmwareName,
                PortName,
                BatchId,
                ErrorMessage,
                IsBatch
            )
            VALUES (
                @qrCode,
                @channelNumber,
                @result,
                @statusCode,
                @statusText,
                @startTime,
                @endTime,
                @durationMs,
                @deviceInfo,
                @firmwareName,
                @portName,
                @batchId,
                @errorMessage,
                @isBatch
            );
            """;

        command.Parameters.Add("@qrCode", SqlDbType.NVarChar, 200).Value = qrCode;
        command.Parameters.Add("@channelNumber", SqlDbType.Int).Value = record.ChannelNumber;
        command.Parameters.Add("@result", SqlDbType.NVarChar, 32).Value = record.Result;
        command.Parameters.Add("@statusCode", SqlDbType.NVarChar, 32).Value = record.StatusCode;
        command.Parameters.Add("@statusText", SqlDbType.NVarChar, 128).Value = record.StatusText;
        command.Parameters.Add("@startTime", SqlDbType.DateTime2).Value = record.StartTime;
        command.Parameters.Add("@endTime", SqlDbType.DateTime2).Value = record.EndTime;
        command.Parameters.Add("@durationMs", SqlDbType.BigInt).Value = record.DurationMs;
        AddNullableNVarChar(command, "@deviceInfo", 512, record.DeviceInfo);
        AddNullableNVarChar(command, "@firmwareName", 260, record.FirmwareName);
        AddNullableNVarChar(command, "@portName", 64, record.PortName);
        AddNullableNVarChar(command, "@batchId", 64, record.BatchId);
        AddNullableNVarChar(command, "@errorMessage", 512, record.ErrorMessage);
        command.Parameters.Add("@isBatch", SqlDbType.Bit).Value = record.IsBatch;
        command.ExecuteNonQuery();
    }

    public bool QrCodeExists(string qrCode)
    {
        qrCode = NormalizeQrCode(qrCode);
        if (string.IsNullOrWhiteSpace(qrCode))
        {
            return false;
        }

        using var connection = new SqlConnection(_connectionString);
        connection.Open();
        return Exists(connection, qrCode);
    }

    public bool HasSuccessfulRecord(string qrCode)
    {
        qrCode = NormalizeQrCode(qrCode);
        if (string.IsNullOrWhiteSpace(qrCode))
        {
            return false;
        }

        using var connection = new SqlConnection(_connectionString);
        connection.Open();
        return Exists(connection, qrCode, "Result = N'Success'");
    }

    public IReadOnlyList<BurnRecord> QueryByQrCode(string qrCode)
    {
        var records = new List<BurnRecord>();
        qrCode = NormalizeQrCode(qrCode);

        if (string.IsNullOrWhiteSpace(qrCode))
        {
            return records;
        }

        using var connection = new SqlConnection(_connectionString);
        connection.Open();

        using var command = connection.CreateCommand();
        command.CommandText =
            """
            SELECT
                Id,
                QrCode,
                ChannelNumber,
                Result,
                StatusCode,
                StatusText,
                StartTime,
                EndTime,
                DurationMs,
                DeviceInfo,
                FirmwareName,
                PortName,
                BatchId,
                ErrorMessage,
                CreatedAt,
                IsBatch
            FROM dbo.BurnRecords
            WHERE QrCode = @qrCode
            ORDER BY StartTime DESC;
            """;
        command.Parameters.Add("@qrCode", SqlDbType.NVarChar, 200).Value = qrCode;

        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            records.Add(new BurnRecord
            {
                Id = reader.GetInt64(0),
                QrCode = reader.GetString(1),
                ChannelNumber = reader.GetInt32(2),
                Result = reader.GetString(3),
                StatusCode = reader.GetString(4),
                StatusText = reader.GetString(5),
                StartTime = reader.GetDateTime(6),
                EndTime = reader.GetDateTime(7),
                DurationMs = reader.GetInt64(8),
                DeviceInfo = GetNullableString(reader, 9),
                FirmwareName = GetNullableString(reader, 10),
                PortName = GetNullableString(reader, 11),
                BatchId = GetNullableString(reader, 12),
                ErrorMessage = GetNullableString(reader, 13),
                CreatedAt = reader.GetDateTime(14),
                IsBatch = !reader.IsDBNull(15) && reader.GetBoolean(15)
            });
        }

        return records;
    }

    private static string NormalizeQrCode(string qrCode)
    {
        return qrCode?.Trim() ?? string.Empty;
    }

    private static bool Exists(SqlConnection connection, string qrCode, string? extraCondition = null)
    {
        using var command = connection.CreateCommand();
        string extraClause = string.IsNullOrWhiteSpace(extraCondition) ? string.Empty : $" AND {extraCondition}";
        command.CommandText = $"SELECT TOP 1 1 FROM dbo.BurnRecords WHERE QrCode = @qrCode{extraClause};";
        command.Parameters.Add("@qrCode", SqlDbType.NVarChar, 200).Value = qrCode;
        object? result = command.ExecuteScalar();
        return result != null && result != DBNull.Value;
    }

    private static void AddNullableNVarChar(SqlCommand command, string name, int size, string? value)
    {
        command.Parameters.Add(name, SqlDbType.NVarChar, size).Value =
            string.IsNullOrWhiteSpace(value) ? DBNull.Value : value.Trim();
    }

    private static string? GetNullableString(SqlDataReader reader, int ordinal)
    {
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }
}
