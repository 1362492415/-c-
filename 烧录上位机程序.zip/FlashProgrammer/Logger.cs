using System;
using System.IO;
using System.Text;

namespace FlashProgrammer;

public enum LogLevel
{
    Debug,
    Info,
    Warning,
    Error
}

public class Logger
{
    private static readonly string LogDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
    private static readonly string LogFileName = "flash_programmer.log";
    private static readonly int MaxLogFileSize = 10 * 1024 * 1024; // 10MB
    private static readonly int MaxLogFiles = 5;
    private static readonly int MaxLogDays = 7;

    private readonly object _lock = new object();
    private Action<string>? _uiCallback;

    public Logger(Action<string>? uiCallback = null)
    {
        _uiCallback = uiCallback;
        InitializeLogDirectory();
        CleanOldLogs();
    }

    private void InitializeLogDirectory()
    {
        if (!Directory.Exists(LogDirectory))
        {
            Directory.CreateDirectory(LogDirectory);
        }
    }

    public void Debug(string message)
    {
        WriteLog(LogLevel.Debug, message);
    }

    public void Info(string message)
    {
        WriteLog(LogLevel.Info, message);
    }

    public void Warning(string message)
    {
        WriteLog(LogLevel.Warning, message);
    }

    public void Error(string message)
    {
        WriteLog(LogLevel.Error, message);
    }

    public void Error(string message, Exception ex)
    {
        WriteLog(LogLevel.Error, $"{message}\n异常: {ex.Message}\n堆栈: {ex.StackTrace}");
    }

    private void WriteLog(LogLevel level, string message)
    {
        string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        string levelStr = GetLevelString(level);
        string logLine = $"[{timestamp}] [{levelStr}] {message}\n";

        // 输出到UI（如果有回调）
        _uiCallback?.Invoke(logLine);

        // 写入文件
        lock (_lock)
        {
            try
            {
                CheckLogSize();
                string logPath = GetCurrentLogPath();
                
                using (var writer = new StreamWriter(logPath, true, Encoding.UTF8))
                {
                    writer.Write(logLine);
                }
            }
            catch
            {
                // 日志写入失败不影响主程序
            }
        }
    }

    private string GetLevelString(LogLevel level)
    {
        return level switch
        {
            LogLevel.Debug => "DEBUG",
            LogLevel.Info => "INFO",
            LogLevel.Warning => "WARN",
            LogLevel.Error => "ERROR",
            _ => "INFO"
        };
    }

    private string GetCurrentLogPath()
    {
        return Path.Combine(LogDirectory, LogFileName);
    }

    private void CheckLogSize()
    {
        string logPath = GetCurrentLogPath();
        
        if (File.Exists(logPath))
        {
            FileInfo fileInfo = new FileInfo(logPath);
            if (fileInfo.Length >= MaxLogFileSize)
            {
                RotateLog();
            }
        }
    }

    private void RotateLog()
    {
        string logPath = GetCurrentLogPath();
        
        // 删除最旧的日志文件
        string oldestLog = Path.Combine(LogDirectory, $"{LogFileName}.{MaxLogFiles}");
        if (File.Exists(oldestLog))
        {
            File.Delete(oldestLog);
        }

        // 将现有日志文件重命名
        for (int i = MaxLogFiles - 1; i >= 1; i--)
        {
            string current = Path.Combine(LogDirectory, $"{LogFileName}.{i}");
            string next = Path.Combine(LogDirectory, $"{LogFileName}.{i + 1}");
            
            if (File.Exists(current))
            {
                if (File.Exists(next))
                {
                    File.Delete(next);
                }
                File.Move(current, next);
            }
        }

        // 将当前日志文件重命名为 .1
        if (File.Exists(logPath))
        {
            string backup = Path.Combine(LogDirectory, $"{LogFileName}.1");
            if (File.Exists(backup))
            {
                File.Delete(backup);
            }
            File.Move(logPath, backup);
        }
    }

    private void CleanOldLogs()
    {
        try
        {
            DateTime cutoffDate = DateTime.Now.AddDays(-MaxLogDays);
            
            foreach (string file in Directory.GetFiles(LogDirectory))
            {
                FileInfo fileInfo = new FileInfo(file);
                if (fileInfo.CreationTime < cutoffDate)
                {
                    fileInfo.Delete();
                }
            }
        }
        catch
        {
            // 清理失败不影响主程序
        }
    }
}