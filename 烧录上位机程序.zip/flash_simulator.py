import serial
import time
import threading
import random
import base64
from io import BytesIO
from enum import Enum
import struct

try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    print("提示：未安装 PIL 库，将使用简单的 Base64 数据代替")


# ==================== 协议定义 ====================

class FrameHeader(Enum):
    """帧头类型定义"""
    HandshakeRequest = 0xAA
    HandshakeResponse = 0xBB
    FileInfoRequest = 0xCC
    FileInfoResponse = 0xDD
    FirmwareData = 0xEE
    FirmwareResponse = 0xFF
    FirmwareComplete = 0x11
    ProgramComplete = 0x22
    ErrorReport = 0x33
    ReadDeviceId = 0x44
    DeviceIdResponse = 0x55
    
    ReadAllFiles = 0xA1
    AllFilesResponse = 0xB1
    ReadSingleFile = 0xA2
    SingleFileResponse = 0xB2
    DeleteSingleFile = 0xA3
    DeleteSingleResponse = 0xB3
    DeleteAllFiles = 0xA4
    DeleteAllResponse = 0xB4
    ReadDeviceInfo = 0xA5
    DeviceInfoResponse = 0xB5
    
    StartProgram = 0xA8
    ProgramConfirm = 0xB8
    QueryFileName = 0xA9
    FileNameResponse = 0xB9
    SelectFileByName = 0xC0
    FileNameSelectResponse = 0xD0
    SelectFileByIndex = 0xC1
    FileIndexSelectResponse = 0xD1
    QueryProgress = 0xC2
    ProgressResponse = 0xD2
    EraseCommand = 0xC3
    EraseConfirm = 0xD3
    SetSpeed = 0xC4
    SpeedConfirm = 0xD4
    SetSerialNumber = 0xC5
    SerialNumberConfirm = 0xD5
    ReadFileCrc = 0xC6
    FileCrcResponse = 0xD6
    
    ReadProgram = 0x3E
    ReadProgramResponse = 0x3F
    ReadProgramData = 0x41
    ProgramDataResponse = 0x42
    EraseSingle = 0x69
    EraseSingleConfirm = 0x6A
    ProgramSingle = 0x6B
    ProgramSingleConfirm = 0x6C
    VerifySingle = 0x6D
    VerifySingleConfirm = 0x6F
    
    ExecuteAll = 0x70
    ExecuteAllConfirm = 0x71
    ProgramAtAddress = 0x72
    AddressProgramConfirm = 0x73


class ProgramStatus(Enum):
    """烧录状态码定义"""
    ReadComplete = 0x11
    InitComplete = 0x22
    ProtectionRemoved = 0x33
    Erasing = 0x44
    EraseComplete = 0x55
    Programming = 0x66
    ProgramComplete = 0x77
    Verifying = 0x88
    VerifyComplete = 0x99
    
    ConnectFailed = 0xAA
    EraseFailed = 0xBB
    ProgramFailed = 0xCC
    VerifyFailed = 0xDD
    ProgramCountExhausted = 0xEE
    VoltageError = 0xFF


# ==================== CRC16-MODBUS 校验算法 ====================

def crc16_modbus(data):
    """计算CRC16-MODBUS校验值"""
    crc = 0xFFFF
    polynomial = 0xA001
    
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc = (crc >> 1) ^ polynomial
            else:
                crc >>= 1
    return crc


# ==================== 协议封包/解包 ====================

def pack_packet(header, number, data=b''):
    """
    封装协议数据包
    :param header: 帧头 (FrameHeader 枚举或字节)
    :param number: 编号（通道号或包序号）
    :param data: 业务数据
    :return: 完整的字节数组数据包
    """
    # 确保header是字节
    if isinstance(header, FrameHeader):
        header_byte = header.value.to_bytes(1, 'little')
    else:
        header_byte = header.to_bytes(1, 'little')
    
    # 计算总长度
    total_length = 1 + 1 + 2 + len(data) + 2
    length_byte = total_length.to_bytes(1, 'little')
    
    # 编号（2字节，小端序）
    number_bytes = number.to_bytes(2, 'little')
    
    # 构建待校验数据
    crc_data = header_byte + length_byte + number_bytes + data
    
    # 计算CRC
    crc = crc16_modbus(crc_data)
    crc_bytes = crc.to_bytes(2, 'little')
    
    # 完整数据包
    packet = crc_data + crc_bytes
    
    return packet


def unpack_packet(raw_data):
    """
    解析协议数据包
    :param raw_data: 原始字节数据
    :return: (header, number, data, remaining_data) 或 (None, None, None, raw_data)
    """
    min_length = 6  # 帧头(1) + 长度(1) + 编号(2) + 数据(0) + 校验(2)
    
    if len(raw_data) < min_length:
        return None, None, None, raw_data
    
    # 读取帧头
    header = FrameHeader(raw_data[0])
    
    # 读取长度
    packet_length = raw_data[1]
    
    if packet_length < min_length:
        return None, None, None, raw_data[1:]  # 无效长度，跳过一个字节
    
    if len(raw_data) < packet_length:
        return None, None, None, raw_data  # 数据不完整
    
    # 验证CRC
    received_crc = int.from_bytes(raw_data[packet_length-2:packet_length], 'little')
    calculated_crc = crc16_modbus(raw_data[:packet_length-2])
    
    if received_crc != calculated_crc:
        return None, None, None, raw_data[1:]  # CRC错误，跳过一个字节
    
    # 解析编号
    number = int.from_bytes(raw_data[2:4], 'little')
    
    # 提取数据
    data = raw_data[4:packet_length-2]
    
    # 剩余数据
    remaining = raw_data[packet_length:]
    
    return header, number, data, remaining


# ==================== 二维码生成 ====================

def generate_qr_data(channel_num):
    """生成简单的二维码数据（或 Base64 图片）"""
    if HAS_PIL:
        # 创建一个简单的图片
        img_size = 180
        img = Image.new('RGB', (img_size, img_size), color='white')
        draw = ImageDraw.Draw(img)
        
        # 画一个简单的图案代替二维码
        margin = 20
        cell_size = 20
        for i in range(0, img_size - 2*margin, cell_size):
            for j in range(0, img_size - 2*margin, cell_size):
                if (i + j) % 40 < 20:
                    draw.rectangle(
                        [margin + i, margin + j, margin + i + cell_size - 1, margin + j + cell_size - 1],
                        fill='black'
                    )
        
        # 画通道号
        try:
            font = ImageFont.truetype("arial.ttf", 36)
        except:
            font = ImageFont.load_default()
        
        text = f"CH{channel_num}"
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        x = (img_size - text_width) // 2
        y = img_size - text_height - 10
        draw.text((x, y), text, font=font, fill='blue')
        
        # 转换为 Base64
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    else:
        # 如果没有 PIL，返回简单的 Base64 数据
        simple_data = f"QRCODE_CH{channel_num}_{random.randint(1000, 9999)}"
        return base64.b64encode(simple_data.encode()).decode('utf-8')


# ==================== 模拟器类 ====================

class FlashSimulator:
    def __init__(self, port, baud_rate=115200):
        self.port = port
        self.baud_rate = baud_rate
        self.ser = None
        self.channels = {i: {"status": "WAITING", "progress": 0} for i in range(1, 13)}
        self.running = False
        self.lock = threading.Lock()
        self.receive_buffer = b''
    
    def connect(self):
        """连接串口"""
        try:
            self.ser = serial.Serial(self.port, self.baud_rate, timeout=1)
            print(f"已连接到串口: {self.port}")
            return True
        except Exception as e:
            print(f"连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        if self.ser and self.ser.is_open:
            self.ser.close()
            print("已断开连接")
    
    def send_packet(self, header, channel_num, data=b''):
        """发送协议数据包"""
        if not self.ser or not self.ser.is_open:
            return
        
        packet = pack_packet(header, channel_num, data)
        try:
            self.ser.write(packet)
            print(f"发送: 帧头=0x{header.value:02X}, 通道={channel_num}, 长度={len(packet)}")
        except Exception as e:
            print(f"发送失败: {e}")
    
    def send_progress(self, channel_num, status, progress):
        """发送进度响应包"""
        # 数据格式：状态码(1字节) + 进度(1字节)
        data = bytes([status.value, progress])
        self.send_packet(FrameHeader.ProgressResponse, channel_num, data)
    
    def send_handshake_response(self, channel_num):
        """发送握手响应"""
        self.send_packet(FrameHeader.HandshakeResponse, channel_num)
    
    def send_device_id_response(self, channel_num):
        """发送设备ID响应"""
        device_id = f"DEVICE_{channel_num:02d}_SIM"
        self.send_packet(FrameHeader.DeviceIdResponse, channel_num, device_id.encode())
    
    def send_device_info_response(self, channel_num):
        """发送设备信息响应"""
        info = f"SIM_V1.0_CH{channel_num:02d}"
        self.send_packet(FrameHeader.DeviceInfoResponse, channel_num, info.encode())
    
    def send_program_confirm(self, channel_num):
        """发送烧录确认"""
        self.send_packet(FrameHeader.ProgramConfirm, channel_num)
    
    def send_program_complete(self, channel_num):
        """发送烧录完成响应"""
        self.send_packet(FrameHeader.ProgramComplete, channel_num)
    
    def send_erase_confirm(self, channel_num):
        """发送擦除确认"""
        self.send_packet(FrameHeader.EraseConfirm, channel_num)
    
    def send_execute_all_confirm(self, channel_num):
        """发送执行全部确认"""
        self.send_packet(FrameHeader.ExecuteAllConfirm, channel_num)
    
    def simulate_channel(self, channel_num):
        """模拟单个通道的烧录过程"""
        with self.lock:
            self.channels[channel_num]["status"] = "ERASING"
            self.channels[channel_num]["progress"] = 0
        
        # 发送擦除状态
        self.send_progress(channel_num, ProgramStatus.Erasing, 0)
        
        # 模拟擦除过程
        for i in range(0, 51, 5):
            if not self.running:
                break
            self.send_progress(channel_num, ProgramStatus.Erasing, i)
            time.sleep(0.2)
        
        if not self.running:
            return
        
        with self.lock:
            self.channels[channel_num]["status"] = "PROGRAMMING"
        
        # 发送烧录状态
        self.send_progress(channel_num, ProgramStatus.Programming, 50)
        
        # 模拟烧录过程
        for i in range(50, 101, 5):
            if not self.running:
                break
            self.send_progress(channel_num, ProgramStatus.Programming, i)
            time.sleep(0.3)
        
        if not self.running:
            return
        
        # 随机决定成功或失败
        success = random.random() < 0.9
        with self.lock:
            if success:
                self.channels[channel_num]["status"] = "SUCCESS"
                self.channels[channel_num]["progress"] = 100
            else:
                self.channels[channel_num]["status"] = "FAILED"
        
        if success:
            # 发送校验状态
            self.send_progress(channel_num, ProgramStatus.Verifying, 100)
            time.sleep(0.3)
            self.send_progress(channel_num, ProgramStatus.VerifyComplete, 100)
            self.send_program_complete(channel_num)
        else:
            # 发送失败状态
            self.send_progress(channel_num, ProgramStatus.ProgramFailed, 0)
        
        print(f"通道 {channel_num} 烧录{'成功' if success else '失败'}")
    
    def start_all(self):
        """启动所有通道的模拟"""
        self.running = True
        threads = []
        for i in range(1, 13):
            t = threading.Thread(target=self.simulate_channel, args=(i,))
            t.start()
            threads.append(t)
            time.sleep(0.1)
        
        for t in threads:
            t.join()
        
        self.running = False
    
    def start_single(self, channel_num):
        """启动单个通道"""
        if not self.running:
            self.running = True
        
        t = threading.Thread(target=self.simulate_channel, args=(channel_num,))
        t.start()
    
    def reset_all(self):
        """重置所有通道状态"""
        self.running = False
        time.sleep(0.5)
        for i in range(1, 13):
            with self.lock:
                self.channels[i]["status"] = "WAITING"
                self.channels[i]["progress"] = 0
            # 发送等待状态（使用ReadComplete代替）
            self.send_progress(i, ProgramStatus.ReadComplete, 0)
        print("所有通道已重置")
    
    def process_received_data(self):
        """处理接收到的数据"""
        if not self.ser or not self.ser.is_open:
            return
        
        try:
            while self.ser.in_waiting > 0:
                data = self.ser.read(self.ser.in_waiting)
                self.receive_buffer += data
                
                # 尝试解析数据包
                while len(self.receive_buffer) >= 6:
                    header, number, data, remaining = unpack_packet(self.receive_buffer)
                    
                    if header is None:
                        # 无法解析，保留剩余数据
                        self.receive_buffer = remaining
                        break
                    
                    # 处理解析出的数据包
                    self.handle_packet(header, number, data)
                    
                    # 更新缓冲区
                    self.receive_buffer = remaining
        
        except Exception as e:
            print(f"接收处理失败: {e}")
    
    def handle_packet(self, header, channel_num, data):
        """处理接收到的数据包"""
        print(f"收到: 帧头=0x{header.value:02X}, 通道={channel_num}, 数据={data.hex()}")
        
        # 根据帧头类型处理
        if header == FrameHeader.HandshakeRequest:
            self.send_handshake_response(channel_num)
        
        elif header == FrameHeader.StartProgram:
            self.send_program_confirm(channel_num)
            # 如果 data 长度为 2，说明是广播掩码启动 (A8 08 [maskLo] [maskHi] [paramLo] [paramHi] ...)
            # 或者如果通道号 > 12，也认为是掩码（兼容老逻辑）
            if len(data) == 2 or channel_num > 12:
                print(f"收到广播启动: 掩码=0x{channel_num:04X}")
                for i in range(1, 13):
                    if (channel_num >> (i-1)) & 1:
                        self.start_single(i)
            else:
                self.start_single(channel_num)
        
        elif header == FrameHeader.ExecuteAll:
            self.send_execute_all_confirm(channel_num)
            if channel_num > 12:
                for i in range(1, 13):
                    if (channel_num >> (i-1)) & 1:
                        self.start_single(i)
            else:
                self.start_single(channel_num)
        
        elif header == FrameHeader.QueryProgress:
            # 如果查询的是掩码，则需要特殊处理（通常上位机会单路查询）
            if channel_num > 12:
                # 仅作为演示，如果收到掩码查询，只返回汇总状态
                self.send_progress(0, ProgramStatus.ReadComplete, 0)
                return

            # 返回当前进度
            with self.lock:
                if channel_num not in self.channels:
                    print(f"警告: 查询了不存在的通道 {channel_num}")
                    return
                status = self.channels[channel_num]["status"]
                progress = self.channels[channel_num]["progress"]
            
            status_code = {
                "WAITING": ProgramStatus.ReadComplete,
                "ERASING": ProgramStatus.Erasing,
                "PROGRAMMING": ProgramStatus.Programming,
                "SUCCESS": ProgramStatus.VerifyComplete,
                "FAILED": ProgramStatus.ProgramFailed
            }.get(status, ProgramStatus.ReadComplete)
            
            self.send_progress(channel_num, status_code, progress)
        
        elif header == FrameHeader.ReadDeviceId:
            self.send_device_id_response(channel_num)
        
        elif header == FrameHeader.ReadDeviceInfo:
            self.send_device_info_response(channel_num)
        
        elif header == FrameHeader.EraseCommand:
            self.send_erase_confirm(channel_num)
            # 模拟擦除
            with self.lock:
                self.channels[channel_num]["status"] = "ERASING"
            
            for i in range(0, 101, 10):
                self.send_progress(channel_num, ProgramStatus.Erasing, i)
                time.sleep(0.1)
            self.send_progress(channel_num, ProgramStatus.EraseComplete, 100)
        
        elif header == FrameHeader.SelectFileByIndex:
            # 选择文件响应
            self.send_packet(FrameHeader.FileIndexSelectResponse, channel_num, b'\x01')  # 成功
        
        elif header == FrameHeader.ReadAllFiles:
            # 返回文件列表（模拟）
            files = b"File1.bin\x00File2.bin\x00File3.bin\x00"
            self.send_packet(FrameHeader.AllFilesResponse, channel_num, files)
        
        else:
            print(f"未处理的帧类型: 0x{header.value:02X}")


# ==================== 主程序 ====================

def main():
    print("=" * 50)
    print("      1拖12烧录模拟器 (协议版本)")
    print("=" * 50)
    print("请输入串口端口号 (例如 COM3):")
    port = input("> ").strip()
    
    simulator = FlashSimulator(port)
    
    if not simulator.connect():
        print("无法连接串口，请检查端口是否正确")
        return
    
    print("\n命令列表:")
    print("  1. start_all  - 一键启动全部通道")
    print("  2. start N    - 启动单个通道 (N=1-12)")
    print("  3. reset_all  - 重置所有通道")
    print("  4. status     - 显示所有通道状态")
    print("  5. exit       - 退出程序")
    
    # 启动接收处理线程
    def receive_thread():
        while simulator.running or simulator.ser.is_open:
            simulator.process_received_data()
            time.sleep(0.01)
    
    simulator.running = True
    t = threading.Thread(target=receive_thread, daemon=True)
    t.start()
    
    # 主命令循环
    while True:
        print("\n请输入命令:")
        cmd = input("> ").strip().lower()
        
        if cmd == "exit":
            simulator.running = False
            time.sleep(0.1)
            break
        
        elif cmd == "start_all":
            print("开始模拟所有通道烧录...")
            simulator.start_all()
            print("所有通道模拟完成")
        
        elif cmd.startswith("start "):
            try:
                ch = int(cmd.split()[1])
                if 1 <= ch <= 12:
                    print(f"开始模拟通道 {ch} 烧录...")
                    simulator.start_single(ch)
                else:
                    print("通道号必须在 1-12 之间")
            except:
                print("命令格式错误，正确格式: start <通道号>")
        
        elif cmd == "reset_all":
            simulator.reset_all()
        
        elif cmd == "status":
            print("\n当前通道状态:")
            for i in range(1, 13):
                status = simulator.channels[i]["status"]
                progress = simulator.channels[i]["progress"]
                print(f"  通道 {i:2d}: {status} ({progress}%)")
        
        else:
            print("未知命令，请重新输入")
    
    simulator.disconnect()


if __name__ == "__main__":
    main()
